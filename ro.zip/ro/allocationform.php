<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'allocationform', language 'ro', version '3.9'.
 *
 * @package     allocationform
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['allocations'] = 'Alocări';
$string['allocationsexported'] = 'Alocări exportate';
$string['choice'] = 'Opțiune {$a->choice}';
$string['deadline'] = 'Termen limită';
$string['defaultrole'] = 'Rol implicit';
$string['editingmode'] = 'Se editează';
$string['editingoption'] = 'Se editează opțiunea';
$string['event:optiondcreated'] = 'Opțiune creată';
$string['event:optiondeleted'] = 'Opțiune ștearsă';
$string['no_allocations'] = 'Nu s-au găsit alocări';
$string['not_set'] = 'Trebuie să selectați o opțiune';
$string['nousersallocated'] = 'Nu există utilizatori alocați';
$string['numberofchoices'] = 'Numărul de opțiuni';
$string['ok_to_continue'] = 'Sunteți sigur(ă) că doriți să continuați?';
$string['option_form_header'] = 'Opțiune nouă';
$string['option_heading'] = 'Antet';
$string['option_restricted'] = 'Utilizatori restricționați';
$string['optioncreated'] = 'Opțiune creată: {$a}';
$string['optiondeleted'] = 'Opțiune ștearsă: {$a}';
$string['optionedited'] = 'Opțiune editată';
$string['optionmodified'] = 'Opțiune modificată: {$a}';
$string['optionnamenumber'] = '{$a->name} ({$a->allocation})';
$string['overviewname'] = 'Alocare: {$a->link}';
$string['privacy:export:allocations'] = 'Alocări';
$string['privacy:export:choices'] = 'Opțiuni';
$string['privacy:export:restrictions'] = 'Restricții';
$string['privacy:metadata:allocationform_choices:choice1'] = 'Prima preferință a utilizatorului';
$string['privacy:metadata:allocationform_choices:choice10'] = 'A zecea preferință a utilizatorului';
$string['privacy:metadata:allocationform_choices:choice2'] = 'A doua preferință a utilizatorului';
$string['privacy:metadata:allocationform_choices:choice3'] = 'A treia preferință a utilizatorului';
$string['privacy:metadata:allocationform_choices:choice4'] = 'A patra preferință a utilizatorului';
$string['privacy:metadata:allocationform_choices:choice5'] = 'A cincea preferință a utilizatorului';
$string['privacy:metadata:allocationform_choices:choice6'] = 'A șasea preferință a utilizatorului';
$string['privacy:metadata:allocationform_choices:choice7'] = 'A șaptea preferință a utilizatorului';
$string['privacy:metadata:allocationform_choices:choice8'] = 'A opta preferință a utilizatorului';
$string['privacy:metadata:allocationform_choices:choice9'] = 'A noua preferință a utilizatorului';
$string['processedmode'] = 'Procesat';
$string['processmode'] = 'Se procesează';
$string['readymode'] = 'Activ';
$string['restrict'] = 'Restricționează';
$string['saved'] = 'Opțiunile dumneavoastră au fost salvate.';
$string['savefail'] = 'Opțiunile dumneavoastră nu au putut fi salvate în Moodle';
$string['startdate'] = 'Data începerii';
$string['unallocated'] = 'Nealocat';
$string['youralloactions'] = 'Ați fost alocat la:';
