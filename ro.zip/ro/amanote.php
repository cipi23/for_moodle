<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'amanote', language 'ro', version '3.9'.
 *
 * @package     amanote
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['amanote:addinstance'] = 'Adaugă un nou fișier annotatable';
$string['amanote:view'] = 'Deschideți fișierul annotatable';
$string['amanotecontent'] = 'Fișiere și subfoldere';
$string['amanotedetails_sizedate'] = '{$a->size} {$a->date}';
$string['amanotedetails_sizetype'] = '{$a->size} {$a->type}';
$string['amanotedetails_sizetypedate'] = '{$a->size} {$a->type} {$a->date}';
$string['amanotedetails_typedate'] = '{$a->type} {$a->date}';
$string['cannotcreatetoken'] = 'Deschide în Amanote';
$string['clicktoamanote'] = 'Deschide în Amanote';
$string['clicktodownloadfile'] = 'Descarccă fișierul PDf';
$string['dnduploadamanote'] = 'Creează fișier annotatable';
$string['downloadfile'] = 'Descarcă';
$string['guestsarenotallowed'] = 'Deschide în Amanote';
$string['modifieddate'] = 'Modificat {$a}';
$string['openinamanote'] = 'Deschide în Amanote';
$string['pluginname'] = 'Amanote';
$string['servicenotavailable'] = 'Deschide în Amanote';
$string['showsize'] = 'Afișează dimensiunea';
$string['unexpectederror'] = 'Deschide în Amanote';
$string['uploadeddate'] = 'Încărcat {$a}';
