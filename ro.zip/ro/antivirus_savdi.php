<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'antivirus_savdi', language 'ro', version '3.9'.
 *
 * @package     antivirus_savdi
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['checkconnectivity'] = 'Conectivitate SAVDI';
$string['clientresult0'] = 'OK';
$string['clientresult1'] = 'S-a detectat virus';
$string['clientresult2'] = 'Eroare';
$string['conntypetcp'] = 'Conexiune TCP/IP';
$string['daemonerroractlikevirus'] = 'Consideră fișierele infectate';
$string['daemonerrordonothing'] = 'Consideră fișierele OK';
$string['errorfileopen'] = 'Eroare la deschiderea fișierului {$a}';
$string['testclientscantestpath'] = 'S-a încărcat fișier temporar';
$string['testclientscanuploaderror'] = 'Eroare la încărcarea fișierului: {$a}.';
$string['testclientuploadandscan'] = 'Încarcă și scanează fișierul';
