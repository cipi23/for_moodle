<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'appointment', language 'ro', version '3.9'.
 *
 * @package     appointment
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['addsession'] = 'Adaugă sesiune';
$string['addstudent'] = 'Adaugă cursant';
$string['advanced'] = 'Avansat';
$string['alllocations'] = 'Toate locațiile';
$string['approve'] = 'Aprobă';
$string['cancel'] = 'Anulează';
$string['cancellation'] = 'Anulare';
$string['enrolled'] = 'înscris';
$string['entitiysession'] = 'Sesiune';
$string['excelformat'] = 'Excel';
$string['export'] = 'Export';
$string['feedback'] = 'Feedback';
$string['field:text'] = 'Text';
$string['format'] = 'Format';
$string['import'] = 'Import';
$string['location'] = 'Locație';
$string['lookfor'] = 'Caută';
$string['maximumpoints'] = 'Numărul maxim de puncte';
$string['options'] = 'Opțiuni';
$string['or'] = 'sau';
$string['sessiondescription'] = 'Descriere';
$string['sessions'] = 'Sesiuni';
$string['sessionstartdateandtime'] = '{$a->startdate}, {$a->starttime} - {$a->endtime} (time zone: {$a->timezone})';
$string['sessionstartdateandtimewithouttimezone'] = '{$a->startdate}, {$a->starttime} - {$a->endtime}';
$string['sessionstartfinishdateandtime'] = '{$a->startdate} - {$a->enddate}, {$a->starttime} - {$a->endtime} (time zone: {$a->timezone})';
$string['sessionstartfinishdateandtimewithouttimezone'] = '{$a->startdate} - {$a->enddate}, {$a->starttime} - {$a->endtime}';
$string['setting:defaultconfirmationmessage_caption'] = 'Mesaj de confirmare';
$string['setting:fromaddressdefault'] = 'moodle@example.com';
$string['settings'] = 'Setări';
$string['status'] = 'Status';
$string['status_approved'] = 'Aprobat';
$string['status_declined'] = 'Refuzat';
$string['xhours'] = '{$a} ore';
$string['xminutes'] = '{$a} minute';
