<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'attcontrol', language 'ro', version '3.9'.
 *
 * @package     attcontrol
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['Aacronym'] = 'A';
$string['Afull'] = 'Absent';
$string['Eacronym'] = 'E';
$string['Pacronym'] = 'P';
$string['Pfull'] = 'Prezent';
$string['add'] = 'Adaugă';
$string['addmultiplesessions'] = 'Adaugă sesiuni multiple';
$string['addrelation'] = '>';
$string['addsession'] = 'Adaugă Sesiune';
$string['addsessions'] = 'Adaugă Sesiunile';
$string['allcourses'] = 'Toate cursurile';
$string['caltoday'] = 'Azi';
$string['changesession'] = 'Modifică sesiunea';
$string['column'] = 'coloană';
$string['columns'] = 'coloane';
$string['course'] = 'Curs';
$string['days'] = 'Zi';
$string['deletesession'] = 'Șterge sesiunea';
$string['deletesessions'] = 'Șterge toate sesiunile';
$string['description'] = 'Descriere';
$string['display'] = 'Afișare';
$string['displaymode'] = 'Mod de afișare';
$string['duration'] = 'Durată';
$string['errorinaddingsession'] = 'Eroare la adăugarea sesiunii';
$string['export'] = 'Export';
$string['groupsession'] = 'Grup';
$string['includeall'] = 'Selectează toate sesiunile';
$string['indetail'] = 'În detaliu...';
$string['months'] = 'Luni';
$string['removerelation'] = '<';
$string['session'] = 'Sesine';
$string['session_help'] = 'Sesiuni';
$string['sessions'] = 'Sesiuni';
$string['sessiontypeshort'] = 'Tip';
$string['settings'] = 'Setări';
$string['status'] = 'Status';
$string['strftimedm'] = '%d.%m';
$string['strftimedmy'] = '%d/%m/%Y';
$string['strftimedmyhm'] = '%d/%m/%Y %H:%M';
$string['strftimedmyw'] = '%d/%m/%y&nbsp;(%a)';
$string['strftimehm'] = '%H:%M';
$string['strftimeshortdate'] = '%d.%m.%Y';
$string['student'] = 'Cursant';
$string['thiscourse'] = 'Acest curs';
$string['update'] = 'Actualizează';
$string['variable'] = 'variabilă';
