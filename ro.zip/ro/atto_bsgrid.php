<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'atto_bsgrid', language 'ro', version '3.9'.
 *
 * @package     atto_bsgrid
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['bsgrid:visible'] = 'Vizibil';
$string['cancel'] = 'Anulează';
$string['col1x3'] = '25%, 75% Coloane';
$string['col2'] = '50% Coloane';
$string['col3'] = '33% Coloane';
$string['col3x1'] = '75%, 25% Coloane';
$string['col4'] = '25% Coloane';
$string['col6'] = '16% Coloane';
$string['column1'] = 'Coloana 1';
$string['column2'] = 'Coloana 2';
$string['column3'] = 'Coloana 3';
$string['column4'] = 'Coloana 4';
$string['column5'] = 'Coloana 5';
$string['column6'] = 'Coloana 6';
$string['enabled_templates'] = 'Șabloane activate:';
$string['insert'] = 'Inserează';
$string['visible'] = 'Viziune';
