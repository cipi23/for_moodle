<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'atto_cloudpoodll', language 'ro', version '3.9'.
 *
 * @package     atto_cloudpoodll
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['appauthorised'] = 'Atto Cloud Poodll este autorizat pentru acest site.';
$string['appnotauthorised'] = 'Atto Cloud Poodll NU este autorizat pentru acest site.';
$string['audio'] = 'Audio';
$string['cancel'] = 'Anulează';
$string['cloudpoodll'] = 'Cloud Poodll';
$string['cloudpoodll:allowaudio'] = 'Se acceptă înregistrarea video';
$string['cloudpoodll:allowsubtitling'] = 'Se acceptă subtitrarea';
$string['cloudpoodll:allowupload'] = 'Se acceptă upload';
$string['cloudpoodll:allowvideo'] = 'Se acceptă înregistrarea video';
$string['cloudpoodll:visible'] = 'Vizibil';
$string['createaudio'] = 'Creați fișier audio';
$string['createvideo'] = 'Creați fișier video';
$string['displaysubs'] = '{$a->subscriptionname} : expiră {$a->expiredate}';
$string['dublin'] = 'Dublin, Irlanda';
$string['en-au'] = 'Engleză (AU)';
$string['en-in'] = 'Engleză (IN)';
$string['en-us'] = 'Engleză (US)';
$string['enablevideo'] = 'Activați înregistrarea video';
$string['fallbackupload'] = 'Încarcă';
$string['forever'] = 'Nu expiră niciodată';
$string['insert'] = 'Inserați';
$string['no'] = 'nu';
$string['options'] = 'Opțiuni';
$string['skin123'] = 'Unu Doi Trei';
$string['subtitle'] = 'Subtitrări';
$string['sydney'] = 'Sydney, Australia';
$string['upload'] = 'Încarcă';
$string['video'] = 'Video';
$string['yes'] = 'da';
