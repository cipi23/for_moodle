<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'atto_matrix', language 'ro', version '3.9'.
 *
 * @package     atto_matrix
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['librarygroup1'] = 'Brackets';
$string['librarygroup2'] = 'Mai mic';
$string['librarygroup3'] = 'Mai mare';
$string['librarygroup4'] = '1xn 2xn';
$string['librarygroup4_title'] = 'Matrici 1xn și 2xn';
$string['librarygroup5'] = '3xn';
$string['librarygroup5_title'] = 'Matrici 3xn';
$string['librarygroup6'] = 'mxn';
$string['librarygroup6_title'] = 'matrici mxn';
$string['librarygroup9'] = 'Matrici';
$string['librarygroup9_title'] = 'Exemple de matrici';
$string['update'] = 'Actualizează';
