<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'atto_poodll', language 'ro', version '3.9'.
 *
 * @package     atto_poodll
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['allowaudiomp3'] = 'Permite înregistrarea MP3';
$string['allowsnapshot'] = 'Permite Snapshot';
$string['allowvideo'] = 'Permite înregistrarea video';
$string['allowwhiteboard'] = 'Permite Whiteboard';
$string['audiomp3_desc'] = 'Înregistrare MP3';
$string['browse'] = 'Caută';
$string['browserepositories'] = 'Caută în depozite...';
$string['cancel'] = 'Anulează';
$string['createpoodll'] = 'Creează poodll';
$string['dialogtitle'] = 'Creează fișier media';
$string['enterurl'] = 'Inserați un URL';
$string['insert'] = 'Inserează';
$string['nothingtoinsert'] = 'Nu există nimic pentru a fi inserat';
$string['openinnewwindow'] = 'Deschide în fereastră nouă';
$string['pluginname'] = 'PoodLL Anywhere(Atto)';
$string['poodll:allowaudiomp3'] = 'Permite înregistrarea MP3';
$string['poodll:allowsnapshot'] = 'Permite Snapshot';
$string['poodll:allowvideo'] = 'Permite înregistrarea video';
$string['poodll:allowwhiteboard'] = 'Permite Whiteboard';
$string['poodll:visible'] = 'Vizibil';
$string['recorderstoshow'] = 'Înregistrări de afișat';
$string['recordtheninsert'] = 'După înregistrare, apăsați Inserare';
$string['settings'] = 'PoodLL Anywhere(Atto)';
$string['show_audiomp3'] = 'Afișează  MP3 recorder';
$string['show_snapshot'] = 'Afișează Snapshot';
$string['show_video'] = 'Afișează  Video recorder';
$string['show_whiteboard'] = 'Afișează Whiteboard';
$string['snapshot_desc'] = 'Faceți o poză';
$string['unpoodll'] = 'Unpoodll';
$string['usewhiteboard'] = 'Alegeți tipul de whiteboard';
$string['visible'] = 'Vizibil';
$string['whiteboard_desc'] = 'Desenează o imagine';
$string['whiteboardheading'] = 'Whiteboard';
