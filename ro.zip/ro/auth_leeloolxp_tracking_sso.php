<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'auth_leeloolxp_tracking_sso', language 'ro', version '3.9'.
 *
 * @package     auth_leeloolxp_tracking_sso
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['auth_leeloolxp_tracking_ssosettings'] = 'Setări';
$string['privacy:metadata:address'] = 'Adresa utilizatorului';
$string['privacy:metadata:alternatename'] = 'Un nume alternativ al utilizatorului.';
$string['privacy:metadata:city'] = 'Orașul utilizatorului';
$string['privacy:metadata:country'] = 'Țara unde se găsește utilizatorul';
$string['privacy:metadata:description'] = 'Detalii generale despre acest utilizator.';
$string['privacy:metadata:firstaccess'] = 'Când a accesat utilizatorul prima data site-ul.';
$string['privacy:metadata:id'] = 'ID-ul utilizatorului';
$string['privacy:metadata:institution'] = 'Instituția a cărui membru este utilizatorul.';
$string['privacy:metadata:lastlogin'] = 'Ultima autentificare a acestui utilizator.';
$string['privacy:metadata:phone1'] = 'Un număr de telefon al acestui utilizator.';
$string['role'] = 'Rol';
$string['student_department_help_txt'] = 'Departament';
$string['student_department_lable'] = 'Departament';
$string['student_institution_help_txt'] = 'Instituții';
$string['student_institution_lable'] = 'Instituții';
$string['teacher_department_help_txt'] = 'Departament';
$string['teacher_department_lable'] = 'Departament';
$string['teacher_institution_help_txt'] = 'Instituții';
$string['teacher_institution_lable'] = 'Instituții';
$string['teacher_num_of_role'] = 'Numărul de roluri';
