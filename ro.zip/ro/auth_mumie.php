<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'auth_mumie', language 'ro', version '3.9'.
 *
 * @package     auth_mumie
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['mumie:addserver'] = 'Adăugați un nou server MUMIE la MOODLE';
$string['mumie:deleteserver'] = 'Eliminați un server MUMIE din MOODLE';
$string['mumie_add_server_button'] = 'Adăugați Server MUMIE';
$string['mumie_authentication_header'] = 'Autentificare & Autorizare';
$string['mumie_delete_button'] = 'Șterge';
$string['mumie_edit_button'] = 'Editează';
$string['mumie_firstname'] = 'Prenume';
$string['mumie_form_required'] = 'solicitat';
$string['mumie_form_server_btn_cancel'] = 'Anulează';
$string['mumie_lastname'] = 'Nume de familie';
$string['mumie_mail'] = 'Email';
$string['mumie_org'] = 'MUMIE Org';
$string['mumie_server_list_heading'] = 'Servere MUMIE configurate';
$string['mumie_server_name'] = 'Denumirea serverului';
$string['mumie_server_name_help'] = 'Vă rugăm să inserați un nume unic pentru această configurare.';
$string['mumie_table_header_name'] = 'Denumirea serverului';
$string['privacy:metadata:auth_mumie_servers:firstname'] = 'Prenumele utilizatorului';
$string['privacy:metadata:auth_mumie_servers:lastname'] = 'Numele de familie al utilizatorului';
