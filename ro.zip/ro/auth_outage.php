<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'auth_outage', language 'ro', version '3.9'.
 *
 * @package     auth_outage
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['clierrorinvalidvalue'] = 'Valoarea nu este validă pentru parametrul: {$a->param}';
$string['datetimeformat'] = '%a %d %h %Y at %I:%M%P %Z';
$string['defaultdescription'] = 'Descriere';
$string['defaulttitle'] = 'Titlu';
$string['description'] = 'Descriere publică';
$string['finish'] = 'Încheiat';
$string['info15secondsbefore'] = 'cu 15 secunde înainte';
$string['infountil'] = 'Până la:';
$string['menumanage'] = 'Administrează';
$string['menusettings'] = 'Setări';
$string['messageoutagebackonline'] = 'Suntem din nou online!';
$string['na'] = 'n/a';
$string['outagecreatecrumb'] = 'Creează';
$string['outageeditcrumb'] = 'Editează';
$string['tableheaderduration'] = 'Durată';
$string['tableheaderstartedtime'] = 'Începe în';
$string['tableheaderstarttime'] = 'Începe în';
$string['tableheadertitle'] = 'Titlu';
$string['title'] = 'Titlu';
