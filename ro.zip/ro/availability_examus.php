<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'availability_examus', language 'ro', version '3.9'.
 *
 * @package     availability_examus
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['allcourses'] = 'Toate cursurile';
$string['allow_to_use_books'] = 'Permiteți folosirea cărților';
$string['allow_to_use_calculator'] = 'Permiteți folosirea calculatorului';
$string['allow_to_use_excel'] = 'Permiteți folosirea excel';
$string['allow_to_use_websites'] = 'Permite utilizarea website-urilor';
$string['allstatuses'] = 'Toate statusurile';
$string['apply_filter'] = 'Aplică filtru';
$string['comment'] = 'Comentariu';
$string['date_modified'] = 'Data ultimei modificări';
$string['details'] = 'Detalii';
$string['duration'] = 'Durata în minute (un multiplu de 30)';
$string['enable'] = 'Activează';
$string['error_setduration'] = 'Durata trebuie să fie un multiplu de 30';
$string['fromdate'] = 'Din data:';
$string['log_details_warning_end'] = 'Încheiere';
$string['log_details_warning_start'] = 'Început';
$string['log_details_warning_title'] = 'Descriere';
$string['log_details_warning_type'] = 'Tip';
$string['log_details_warnings'] = 'Avertizări';
$string['module'] = 'Modul';
$string['pluginname'] = 'Proctoring by Examus';
$string['rules'] = 'Reguli';
$string['settings'] = 'Setări Examus';
$string['status'] = 'Status';
$string['time_scheduled'] = 'Programat';
$string['title'] = 'Examus';
$string['warnings'] = 'Avertizări';
