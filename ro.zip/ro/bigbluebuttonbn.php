<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'bigbluebuttonbn', language 'ro', version '3.9'.
 *
 * @package     bigbluebuttonbn
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['bbbduetimeoverstartingtime'] = 'Termenul de predare pentru această activitatea trebuie să fie mai mare decât timpul de pornire';
$string['bbbdurationwarning'] = 'Durata maximă pentru această sesiune este de %duration% minute.';
$string['bbbrecordwarning'] = 'Această sesiune e posibil să fie înregistrată.';
$string['bigbluebuttonbn'] = 'BigBlueButton';
$string['bigbluebuttonbn:addinstance'] = 'Adăugare întâlnire nouă';
$string['bigbluebuttonbn:join'] = 'Înscriete la o întâlnire';
$string['bigbluebuttonbn:managerecordings'] = 'Administrare înregistrări';
$string['calendarstarts'] = '{$a} este programat pentru';
$string['completionengagementemojis'] = 'Emojis';
$string['config_default_messages'] = 'Mesaje implicite';
$string['config_disablecam_default_description'] = 'Dacă se activează această opțiune, webcam-urile vor fi';
$string['config_extended_capabilities'] = 'Configurarea capabilităților extinse';
$string['config_general'] = 'Configurare generală';
$string['config_general_description'] = 'Aceste setări sunt <b>always</b> folosite';
$string['config_meetingevents_enabled'] = 'Înregistrează evenimente live';
$string['config_scheduled_duration_enabled'] = 'Este activată calcularea duratei';
$string['email_body_notification_meeting_by'] = 'de către';
$string['email_body_notification_meeting_description'] = 'Descriere';
$string['email_body_notification_meeting_details'] = 'Detalii';
$string['email_body_notification_meeting_end_date'] = 'Data încheierii';
$string['email_body_notification_meeting_has_been'] = 'a fost';
$string['email_body_notification_meeting_start_date'] = 'Data începerii';
$string['email_body_notification_meeting_title'] = 'Titlu';
$string['email_body_recording_ready_is_ready'] = 'este gata';
$string['email_footer_sent_from'] = 'din cursul';
$string['event_activity_created'] = 'Activitate creată';
$string['event_activity_deleted'] = 'Activitate ștearsă';
$string['event_activity_updated'] = 'Activitate actualizată';
$string['event_activity_viewed'] = 'Activitate văzută';
$string['event_recording_deleted'] = 'Înregistrare ștearsă';
$string['event_recording_edited'] = 'Înregistrare editată';
$string['event_recording_imported'] = 'Înregistrare importată';
$string['event_recording_protected'] = 'Înregistrare protejată';
$string['event_recording_published'] = 'Înregistrare publicată';
$string['event_recording_viewed'] = 'Înregistrare văzută';
$string['general_error_not_allowed_to_create_instances'] = 'Utilizatorul nu are permisiunea să creeze niciun fel de instanță.';
$string['general_error_unable_connect'] = 'Imposibil de realizat conectarea. Vă rugăm să verificați URL-ul serverului BigBlueButton și verificați dacă serverul BigBlueButton este pronit.';
$string['index_confirm_end'] = 'Doriți încheierea clasei virtuale?';
$string['index_disabled'] = 'dezactivat';
$string['index_enabled'] = 'activat';
$string['index_ending'] = 'Încheierea clasei virtuale... va rugăm să așteptați';
$string['index_error_checksum'] = 'A apărut o eroare la suma de control. Verificați că security salt este introdus corect.';
$string['index_error_forciblyended'] = 'Înscrierea la această întâlnire este imposibilă, deoarece acesta a fost încheiată manual.';
$string['index_error_unable_display'] = 'Nu se pot afișa întâlnirile. Vă rugăm să verificați URL-ul serverului BigBlueButton și verificați dacă serverul BigBlueButton este pornit.';
$string['index_heading'] = 'Camere BigBlueButton';
$string['index_heading_actions'] = 'Acțiuni';
$string['index_heading_group'] = 'Grup';
$string['index_heading_moderator'] = 'Moderatori';
$string['index_heading_name'] = 'Cameră';
$string['index_heading_recording'] = 'Înregistrare';
$string['index_heading_users'] = 'Utilizatori';
$string['index_heading_viewer'] = 'Spectatori';
$string['indicator:cognitivedepth'] = 'BigBlueButtonBN cognitiv';
$string['indicator:socialbreadth'] = 'BigBlueButtonBN social';
$string['instance_type_recording_only'] = 'Doar înregistrări';
$string['minute'] = 'minut';
$string['minutes'] = 'minute';
$string['mod_form_block_general'] = 'Setări generale';
$string['mod_form_block_participants'] = 'Rol atribuit în timpul sesiunii live';
$string['mod_form_block_presentation'] = 'Conținutul prezentării';
$string['mod_form_block_record'] = 'Setări înregistrare';
$string['mod_form_block_schedule'] = 'Programare pentru sesiuni';
$string['mod_form_field_conference_name'] = 'Numele conferinței';
$string['mod_form_field_disablecam'] = 'Dezactivează webcamere';
$string['mod_form_field_disablemic'] = 'Dezactivează microfoanele';
$string['mod_form_field_disableprivatechat'] = 'Dezactivează chat-ul privat';
$string['mod_form_field_disablepublicchat'] = 'Dezactivează chat-ul public';
$string['mod_form_field_duration'] = 'Durată';
$string['mod_form_field_duration_help'] = 'Setarea duratei pentru o întâlnire va stabili durata maximă pentru care se menține activă o întâlnire înainte de a termina înregistrarea.';
$string['mod_form_field_instanceprofiles'] = 'Tipul de instanță';
$string['mod_form_field_intro'] = 'Descriere';
$string['mod_form_field_name'] = 'Nume clasa virtuală';
$string['mod_form_field_notification'] = 'Trimite notificae';
$string['mod_form_field_notification_msg_at'] = 'la';
$string['mod_form_field_notification_msg_created'] = 'adăugat';
$string['mod_form_field_notification_msg_modified'] = 'actualizat';
$string['mod_form_field_participant_add'] = 'Adaugă participant';
$string['mod_form_field_participant_bbb_role_moderator'] = 'Moderator';
$string['mod_form_field_participant_bbb_role_viewer'] = 'Spectator';
$string['mod_form_field_participant_list'] = 'Lista participanților';
$string['mod_form_field_participant_list_action_add'] = 'Adaugă';
$string['mod_form_field_participant_list_action_remove'] = 'Șterge';
$string['mod_form_field_participant_list_text_as'] = 'participă la sesiune ca';
$string['mod_form_field_participant_list_type_all'] = 'Toți utilizatorii înrolați';
$string['mod_form_field_participant_list_type_owner'] = 'Proprietar';
$string['mod_form_field_participant_list_type_role'] = 'Rol';
$string['mod_form_field_participant_list_type_user'] = 'Utilizator';
$string['mod_form_field_record'] = 'Sesiunea poate fi înregistrată';
$string['mod_form_field_recordallfromstart'] = 'Înregistrează tot de la început';
$string['mod_form_field_voicebridge'] = 'Pod voce';
$string['mod_form_field_voicebridge_help'] = 'Numărul conferinței de voce pentru participanții îl introduc pentru a se înscrie la conferința de voce.';
$string['mod_form_field_wait'] = 'Studenții trebuie să aștepte până când un moderator se alătură';
$string['mod_form_field_welcome'] = 'Mesaj de întâmpinare';
$string['mod_form_field_welcome_default'] = '<br>Bine ati venit la <b>%%CONFNAME%%</b>!<br><br>Pentru a înțelege cum funcționează BigBlueButton vezi<a href="event:http://www.bigbluebutton.org/content/videos"><u>tutorialele video</u></a>.<br><br>Pentru a vă alătura audio faceți clic pe pictograma căști (colțul din stânga sus).<b>Vă rugăm să folosiți un set de căști pentru a evita producerea de zgomot pentru alții.</b>';
$string['mod_form_field_welcome_help'] = 'Înlocuiește mesajul implicit pentru serverul BigBlueButton. Mesajul poate cuprinde cuvinte cheie (%%CONFNAME%%, %%DIALNUM%%, %%CONFNUM%%) care vor fi înlocuite în mod automat și de asemenea tag-uri HTML, cum ar <b>...</b> sau <i></i>';
$string['modulename'] = 'BigBlueButtonBN';
$string['modulename_help'] = 'BigBlueButtonBN vă permite să creați link-uri din cadrul Moodle către săli de clasă online, în timp real, folosind BigBlueButton, un sistem opensource de conferințe web pentru învățământul la distanță.

Folosind BigBlueButtonBN aveți posibilitatea să specificați titlu, descriere, intrare din calendar (care dă un interval de date pentru înscrierea la sesiune), grupuri, precum și detalii despre înregistrarea sesiunii on-line.

Pentru a vizualiza înregistrările anterioare, se poate adaugă o resursă RecordingsBN la acest curs.';
$string['modulenameplural'] = 'BigBlueButtonBN';
$string['pluginadministration'] = 'Adminstrare BigBlueButtonBN';
$string['pluginname'] = 'BigBlueButtonBN';
$string['removedevents'] = 'Evenimente șterese';
$string['removedrecordings'] = 'Șterge înregistrări';
$string['resetevents'] = 'Șterge evenimente';
$string['resetrecordings'] = 'Șterge înregistrări';
$string['resettags'] = 'Șterge etichete';
$string['sendnotification'] = 'Trimite notificări';
$string['started_at'] = 'Început';
$string['starts_at'] = 'Începe';
$string['view_conference_action_end'] = 'Încheie sesiunea';
$string['view_error_bigbluebutton'] = 'BigBlueButton a răspuns cu erori. {$a}';
$string['view_error_no_group'] = 'Nu există grupuri configurare încă. Vă rugăm să creați grupuri înainte de a încerca să vă înscrieți la întâlnire.';
$string['view_error_no_group_student'] = 'Tu nu ai fost înscris într-un grup. Vă rugăm să contactați profesorului sau administrator.';
$string['view_error_no_group_teacher'] = 'Nu există grupuri de configurat încă. Vă rugăm să creați grupuri sau contactați administratorul.';
$string['view_error_unable_join'] = 'Nu se poate realiza înscrierea la întâlnire. Vă rugăm să verificați URL-ul serverului BigBlueButton și verificați dacă serverul BigBlueButton este pornit.';
$string['view_error_unable_join_student'] = 'Nu se poate conecta la server BigBlueButton. Vă rugăm să contactați profesorului sau administrator.';
$string['view_error_unable_join_teacher'] = 'Nu se poate conecta la server BigBlueButton. Vă rugăm să contactați administratorul.';
$string['view_error_url_missing_parameters'] = 'Acești parametri lipsesc în acest URL';
$string['view_error_userlimit_reached'] = 'A fost atins numărul de utilizatori admiși într-o ședință.';
$string['view_groups_selection'] = 'Selectați grupul la care doriți să vă înscrieți și confirmați acțiunea';
$string['view_groups_selection_join'] = 'Înscriere';
$string['view_login_moderator'] = 'Autentificare în calitate de moderator ...';
$string['view_login_viewer'] = 'Autentificare în calitate de participant ...';
$string['view_message_and'] = 'și';
$string['view_message_conference_has_ended'] = 'Conferința s-a încheiat';
$string['view_message_conference_in_progress'] = 'Conferința este în desfășurare';
$string['view_message_conference_not_started'] = 'Conferința nu a început încă';
$string['view_message_finished'] = 'Activitatea s-a încheiat.';
$string['view_message_has_joined'] = 's-a alăturat';
$string['view_message_have_joined'] = 's-au alăturat';
$string['view_message_hour'] = 'oră';
$string['view_message_hours'] = 'ore';
$string['view_message_minute'] = 'minut';
$string['view_message_minutes'] = 'minute';
$string['view_message_moderator'] = 'moderator';
$string['view_message_moderators'] = 'moderatori';
$string['view_message_norecordings'] = 'Nu există înregistrări de afișat.';
$string['view_message_notavailableyet'] = 'Această sesiune nu este încă disponibilă';
$string['view_message_session_for'] = 'sesiunea pentru';
$string['view_message_session_has_user'] = 'Este';
$string['view_message_session_has_users'] = 'Sunt';
$string['view_message_session_no_users'] = 'Nu există utilizatori în această sesiune';
$string['view_message_session_started_at'] = 'Sesiunea a început la';
$string['view_message_user'] = 'utilizator';
$string['view_message_users'] = 'utilizatori';
$string['view_message_viewer'] = 'spectator';
$string['view_message_viewers'] = 'spectatori';
$string['view_noguests'] = 'BigBlueButtonBN nu este deschis pentru vizitatori';
$string['view_nojoin'] = 'Nu aveți un rol permis să se înscrie la această sesiune.';
$string['view_recording'] = 'înregistrare';
$string['view_recording_actionbar'] = 'Toolbar';
$string['view_recording_activity'] = 'Activitate';
$string['view_recording_button_return'] = 'Mergi înapoi';
$string['view_recording_course'] = 'Curs';
$string['view_recording_date'] = 'Dată';
$string['view_recording_delete_confirmation'] = 'Sunteți sigur că doriți să ștergeți acest {$a}?';
$string['view_recording_description'] = 'Descriere';
$string['view_recording_duration'] = 'Durată';
$string['view_recording_duration_min'] = 'min';
$string['view_recording_format_podcast'] = 'Podcast';
$string['view_recording_format_presentation'] = 'Prezentare';
$string['view_recording_format_statistics'] = 'Statistici';
$string['view_recording_format_video'] = 'Video';
$string['view_recording_length'] = 'Lungime';
$string['view_recording_list_action_delete'] = 'Se șterge';
$string['view_recording_list_action_edit'] = 'Se actualizează';
$string['view_recording_list_actionbar'] = 'Bară de unelte';
$string['view_recording_list_actionbar_delete'] = 'Sterge';
$string['view_recording_list_actionbar_edit'] = 'Editează';
$string['view_recording_list_actionbar_hide'] = 'Ascunde';
$string['view_recording_list_actionbar_import'] = 'Import';
$string['view_recording_list_actionbar_publish'] = 'Publică';
$string['view_recording_list_actionbar_show'] = 'Arată';
$string['view_recording_list_activity'] = 'Activitate';
$string['view_recording_list_course'] = 'Curs';
$string['view_recording_list_date'] = 'Dată';
$string['view_recording_list_description'] = 'Descriere';
$string['view_recording_list_duration'] = 'Durată';
$string['view_recording_list_recording'] = 'Înregistrare';
$string['view_recording_meeting'] = 'Întâlnire';
$string['view_recording_modal_button'] = 'Aplică';
$string['view_recording_name'] = 'Nume';
$string['view_recording_playback'] = 'Playback';
$string['view_recording_preview'] = 'Previzualizare';
$string['view_recording_recording'] = 'Înregistrare';
$string['view_recording_tags'] = 'Etichete';
$string['view_recording_unpublish_confirmation'] = 'Sunteți sigur că doriți să publicați acest {$a}?';
$string['view_recording_yui_first'] = 'Primul';
$string['view_recording_yui_last'] = 'Ultimul';
$string['view_recording_yui_next'] = 'Următor';
$string['view_recording_yui_page'] = 'Pagină';
$string['view_recording_yui_prev'] = 'Precedent';
$string['view_recording_yui_rows'] = 'Rânduri';
$string['view_recording_yui_show_all'] = 'Afișează tot';
$string['view_section_title_presentation'] = 'Fișier de prezentare';
$string['view_section_title_recordings'] = 'Înregistrări';
