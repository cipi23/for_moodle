<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'block_annotate', language 'ro', version '3.9'.
 *
 * @package     block_annotate
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['access_default_msg'] = 'Individual (implicit). Poate fi modificat în config.';
$string['access_shareuser_msg'] = 'Proprietarul documentului:';
$string['access_shareuser_msg_dft'] = 'Încă nu este setat. Utilizați config.';
$string['annotate:accessannotate'] = 'Accesați Annotate';
$string['annotate:addinstance'] = 'Adăugați block-ul Annotate';
$string['annotate_api_key_lbl'] = 'Cheia API pentru utilizator';
$string['annotate_header_config'] = 'Setările serverului Annotate';
$string['annotate_header_description'] = 'Aici puteți insera parametrii necesari pentru a vă conecta la serverul dumneavoastră Annotate.';
$string['annotate_server_uri_default'] = 'http://localhost/annotate';
$string['annotate_server_uri_lbl'] = 'Server URI Annotate';
$string['config_access_label'] = 'Acces';
$string['config_group_access'] = 'Grup';
$string['config_header_label'] = 'Opțiuni pentru partajarea documentului';
$string['config_individual_access'] = 'Individual';
$string['config_shareuser_label'] = 'Proprietarul documentului (numai grup)';
$string['enter_email_msg'] = 'Inserați email';
$string['invalid_email_msg'] = 'Email nevalid';
$string['pluginname'] = 'Annotate';
$string['transfer_error'] = 'Eroare';
$string['transfer_error_msg'] = 'A apărut o probemă la transferul către Annotate pentru a vedea documentul. Vă rugăm să contactați administratorul serverului.';
