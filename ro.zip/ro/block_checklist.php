<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'block_checklist', language 'ro', version '3.9'.
 *
 * @package     block_checklist
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['checklist'] = 'Checklist';
$string['checklist:addinstance'] = 'Adaugă un nou block Checklist';
$string['checklist:myaddinstance'] = 'Adaugă un nou block Ckecklist la pagina mea Moodle';
$string['checklistoverview'] = 'Overview checklist';
$string['choosechecklist'] = 'Alege checklist';
$string['choosegroup'] = 'Grup implicit';
$string['nochecklist'] = 'Vă rugăm să modificați acest block pentru a selecta un checklist care va fi afișat';
$string['nochecklistplugin'] = 'Trebuie să instalați ultima versiune a plugin-ului checklist-ului pentru ca acest block să funcționeze';
$string['notenrolled'] = 'Nu sunteți înscris la niciun curs';
$string['nousers'] = 'Fără utilizatori';
$string['pluginname'] = 'Checklist';
