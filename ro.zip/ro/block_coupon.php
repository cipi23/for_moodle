<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'block_coupon', language 'ro', version '3.9'.
 *
 * @package     block_coupon
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['action:coupon:delete'] = 'Șterge cupon';
$string['action:coupon:delete:confirm'] = 'Sunteți sigur(ă) că doriți să ștergeți acest cupon? Acest lucru nu poate fi anulat!';
$string['action:error:delete'] = 'Șterge eroarea';
$string['and'] = 'și';
$string['blockname'] = 'Cupon';
$string['button:next'] = 'Următorul';
$string['button:save'] = 'Generează cupon';
$string['cohort'] = 'cohortă';
$string['confirm_coupons_sent_subject'] = 'Toate cupoanele au fost trimise';
$string['coupon:addinstance'] = 'Adaugă un nou block Coupon';
$string['coupon:administration'] = 'Administrează block-ul Coupon';
$string['coupon:deleted'] = 'Cuponul a fost șters';
$string['coupon:generatecoupons'] = 'Generează un cupon nou';
$string['coupon:send:fail'] = 'Trimitere email eșuată! Motivul: {$a}';
$string['coupon_mail_subject'] = 'Cuponul Moodle a fost generat';
$string['course'] = 'curs';
$string['days_access'] = '{$a} zile din';
$string['error:coupon_amount_too_high'] = 'Vă rugăm să introduceți o valoare între {$a->min} și {$a->max}.';
$string['error:course-not-found'] = 'Cursul nu a putut fi găsit.';
$string['error:invalid_coupon_code'] = 'Ați introdus un cod nevalid de cupon.';
$string['error:invalid_email'] = 'Vă rugăm să inserați o adresă de email validă.';
$string['error:no_coupons_submitted'] = 'Niciunul din cupoanele dumneavoastră nu a fost folosit încă.';
$string['error:nopermission'] = 'Nu aveți permisiunea de a efectua această acțiune.';
$string['error:recipients-extension'] = 'Puteți uploada doar fișiere  .csv.';
$string['error:required'] = 'Acest câmp este necesar.';
$string['error:sessions-expired'] = 'Sesiunea dumneavoastră a expirat. Vă rugăm să încercați din nou.';
$string['error:wrong_code_length'] = 'Vă rugăm să introduceți un număr cuprins între 6 și 32.';
$string['error:wrong_doc_page'] = 'Încercați să accesați o pagină care nu există.';
$string['heading:administration'] = 'Administrează';
$string['heading:coupon_type'] = 'Tipul cuponului';
$string['heading:csvForm'] = 'Setări CSV';
$string['heading:general_settings'] = 'Ultimele setări';
$string['heading:generatecoupons'] = 'Generează cupoane';
$string['heading:imageupload'] = 'Încarcă imagine';
$string['heading:info'] = 'Info';
$string['heading:input_cohorts'] = 'Selectează cohorte';
$string['heading:input_course'] = 'Selectează curs';
$string['heading:input_groups'] = 'Selectează grupuri';
$string['heading:label_instructions'] = 'Instrucțiuni';
$string['heading:manualForm'] = 'Setări manuale';
$string['label:alternative_email'] = 'Email alternativ';
$string['label:api_enabled'] = 'Activați API';
$string['label:api_password'] = 'Parolă API';
$string['label:api_user'] = 'Utilizator API';
$string['label:cleanupage'] = 'Vârsta maximă?';
$string['label:cohort'] = 'Cohortă';
$string['label:coupon_cohorts'] = 'Cohortă(Cohorte)';
$string['label:coupon_connect_course'] = 'Adăugați curs(cursuri)';
$string['label:coupon_courses'] = 'Curs(Cursuri)';
$string['label:coupon_email'] = 'Aresă email';
$string['label:coupon_recipients'] = 'Destinatari';
$string['label:coupon_recipients_txt'] = 'Destinatari';
$string['label:email_body'] = 'Mesaj email';
$string['label:no_courses_connected'] = 'Nu există cursuri conectate la această cohortă.';
$string['label:selected_cohort'] = 'Cohortă(e) selectată(e)';
$string['label:selected_courses'] = 'Cursuri selectate';
$string['label:selected_groups'] = 'Grup(uri) selectat(e)';
$string['label:type_cohorts'] = 'Cohortă(e)';
$string['label:type_course'] = 'Curs';
$string['label:use_alternative_email'] = 'Utilizați email alternativ';
$string['page:generate_coupon.php:title'] = 'Generați cupoane';
$string['page:generate_coupon_step_five.php:title'] = 'Generați cupoane';
$string['page:generate_coupon_step_four.php:title'] = 'Generați cupoane';
$string['page:generate_coupon_step_three.php:title'] = 'Generați cupoane';
$string['page:generate_coupon_step_two.php:title'] = 'Generați cupoane';
$string['page:unused_coupons.php:title'] = 'Cupoane neutilizate';
$string['pdf-meta:keywords'] = 'Cupon Moodle';
$string['pdf-meta:subject'] = 'Cupon Moodle';
$string['pdf-meta:title'] = 'Cupon Moodle';
$string['pdf:titlename'] = 'Cupon Moodle';
$string['pdf_generated'] = 'Cupoanele au fost atașate acestui email în fișiere PDF .<br /><br />';
$string['pluginname'] = 'Cupon';
$string['report:cohorts'] = 'Cohortă';
$string['report:dateformat'] = '%d-%m-%Y %H:%M:%S';
$string['report:dateformatymd'] = '%d-%m-%Y';
$string['report:heading:action'] = 'Acțiune(i)';
$string['report:heading:coupon'] = 'Cupon';
$string['report:heading:coursename'] = 'Nume curs';
$string['report:heading:coursetype'] = 'Tip de curs';
$string['report:heading:datestart'] = 'Data de începere';
$string['report:heading:errormessage'] = 'Eroare';
$string['report:heading:errortype'] = 'Tip';
$string['report:heading:grade'] = 'Notă';
$string['report:heading:status'] = 'Status';
$string['report:heading:timecreated'] = 'Dată';
$string['report:heading:user'] = 'Utilizator';
$string['report:immediately'] = 'Imediat';
$string['report:status_completed'] = 'Curs completat';
$string['report:status_not_started'] = 'Curs neînceput încă';
$string['report:status_started'] = 'Curs început';
$string['str:mandatory'] = 'Obligatoriu';
$string['str:optional'] = 'Opțional';
$string['tab:apidocs'] = 'API Docs';
$string['tab:unused'] = 'Cupoane neutilizate';
$string['tab:used'] = 'Cupoane utilizate';
$string['tab:wzcouponimage'] = 'Imagine șablon';
$string['tab:wzcoupons'] = 'Generează cupon(cupoane)';
$string['textsettings'] = 'Setări text';
$string['th:action'] = 'Acțiune(i)';
$string['th:cohorts'] = 'Cohortă';
$string['th:for_user_email'] = 'Planificat pentru';
$string['th:groups'] = 'Grup(uri)';
$string['th:immediately'] = 'Imediat';
$string['th:issend'] = 'Trimis?';
$string['url:view_reports'] = 'Vezi rapoarte';
$string['url:view_unused_coupons'] = 'Vezi cupoane neutulizate';
$string['view:api:heading'] = 'Cupon API';
$string['view:api:title'] = 'Cupon API';
$string['view:errorreport:heading'] = 'Raport - Erori cupon';
$string['view:errorreport:title'] = 'Raport - Erori cupon';
$string['view:generate_coupon:heading'] = 'Generează cupon';
$string['view:generate_coupon:title'] = 'Generează cupon';
$string['view:reports-unused:heading'] = 'Raport - Cupoane neutilizate';
$string['view:reports-unused:title'] = 'Raport - Cupoane neutilizate';
$string['view:reports-used:heading'] = 'Raport - Cupoane utilizate';
$string['view:reports-used:title'] = 'Raport - Cupoane utilizate';
