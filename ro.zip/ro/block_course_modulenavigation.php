<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'block_course_modulenavigation', language 'ro', version '3.9'.
 *
 * @package     block_course_modulenavigation
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['config_blocktitle'] = 'Denumirea blocului';
$string['config_blocktitle_default'] = 'Cuprins';
$string['config_onesection'] = 'Afișați doar secțiunea cuentă';
$string['course_modulenavigation:addinstance'] = 'Adăugați un nou block Conținuturile cursului';
$string['notusingsections'] = 'Acest format de curs nu utilizează secțiuni.';
$string['toggleclickontitle'] = 'Clik pe titlu';
$string['toggleclickontitle_desc'] = '\'Afișează meniul\' sau \'Se trece la acea pagină ".';
$string['toggleclickontitle_menu'] = 'Afișează meniul';
$string['toggleclickontitle_page'] = 'Merge la pagina';
$string['toggleshowlabels'] = 'Afișează etichetele';
$string['toggletitles'] = 'Afișează doar titlurile';
