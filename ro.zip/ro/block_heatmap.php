<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'block_heatmap', language 'ro', version '3.9'.
 *
 * @package     block_heatmap
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['cache0min'] = 'Dezactivați caching';
$string['cache10min'] = '10 minute';
$string['cache120min'] = '2 ore';
$string['cache1min'] = '1 minut';
$string['cache30min'] = '30 minute';
$string['cache5min'] = '5 minute';
$string['cache60min'] = 'o oră';
$string['cachelife_help'] = 'Memoria cache este utilizată pentru a reține rezultatele și pentru reducerea impactului autentificărilor. Modificările pot să nu apară imediat, cu excepția cazului în eliminați cache-uri.';
$string['nologentries'] = 'Nu a fost găsită nicio activitate';
$string['sincecoursestart'] = '(De la data începerii cursului)';
$string['sinceforever'] = 'Toate autentificările anterioare';
$string['sincestart'] = 'De la data începerii cursului';
$string['totalviews'] = '<em>Vizualizări totale:</em> {$a}';
$string['updated'] = 'Actualizat: {$a}';
$string['views'] = 'Vizualizări';
$string['whattoshow'] = 'Ce să apară pe pagina de curs';
