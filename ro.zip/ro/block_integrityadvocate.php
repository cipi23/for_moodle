<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'block_integrityadvocate', language 'ro', version '3.9'.
 *
 * @package     block_integrityadvocate
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['config_blockversion'] = 'Versiune';
$string['config_default_title'] = 'Integrity Advocate';
$string['error_nousers'] = 'Nu s-au găsit utilizatori';
$string['flag_comment'] = 'Detalii';
$string['fullname'] = 'Denumirea completă a cursului';
$string['no_local_participants'] = 'Nu s-au găsit participanți la curs';
$string['no_modules_message'] = 'Nu s-au găsit module.';
$string['now_indicator'] = 'ACUM';
$string['privacy:metadata:block_integrityadvocate:email'] = 'Adresa dumneavoastră de email.';
$string['privacy:metadata:block_integrityadvocate:fullname'] = 'Numele dumneavoastră complet.';
$string['session_start'] = 'Start';
$string['session_status'] = 'Status';
$string['shortname'] = 'Denumirea prescurtată a cursului';
$string['status_invalid_override'] = 'Nu e valid';
$string['status_valid'] = 'Valid';
