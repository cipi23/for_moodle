<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'block_massaction', language 'ro', version '3.9'.
 *
 * @package     block_massaction
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['action_delete'] = 'Ștergeți';
$string['action_hide'] = 'Ascunde';
$string['action_show'] = 'Afișează';
$string['allitems'] = 'Selectați tot în secțiune:';
$string['blockname'] = 'Acțiuni în masă';
$string['blocktitle'] = 'Acțiuni în masă';
$string['confirmation'] = 'Sunteți sigur(ă) că doriți să ștergeți {$a} itemii?';
$string['invalidaction'] = 'Acțiune necunoscută: {$a}';
$string['invalidcourseid'] = 'ID curs nevalid';
$string['invalidcoursemodule'] = 'Modul curs nevalid';
$string['invalidmoduleid'] = 'ID modul nevalid: {$a}';
$string['itemsin'] = 'itemi în';
$string['missingparam'] = 'Eroare de codare: lipsește parametrul necesar JSON "{$a}"';
$string['noaction'] = 'Nicio acțiune specificată';
$string['pluginname'] = 'Block acțiuni în masă';
$string['section'] = 'Topic';
$string['section_zero'] = 'General';
$string['sectionnotexist'] = 'Secțiunea target nu există';
$string['selectall'] = 'Selectați  tot';
$string['selecttarget'] = 'Vă rugăm să selectați o secțiune target în care să mutați elementele';
$string['topic'] = 'Topic';
$string['week'] = 'W';
$string['withselected'] = 'Cu ce ați selectat';
