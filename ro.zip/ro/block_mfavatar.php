<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'block_mfavatar', language 'ro', version '3.9'.
 *
 * @package     block_mfavatar
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['avatar_initials'] = 'Avatarurile inițiale';
$string['avatar_initials_forced'] = 'Suprascrie poza utilizatorului';
$string['avatar_initials_forced_desc'] = 'Dacă este activat, poza utilizatorului va fi suprascrisă.';
$string['failed'] = 'Eroare: Uploading-ul a eșuat';
$string['failed:disableuserimages'] = 'Eroare: Site-ul a dezactivat imaginile utilizatorului';
$string['failed:permission_editownprofile'] = 'Eroare: utilizatorul nu își poate schimba imaginile';
$string['failed:sesskey'] = 'Eroare: nu s-au salvat modificările, mai sunteți autentificat? Actualizați pagina și reîncercați';
$string['flash:failed_saving'] = 'Eroare la salvarea snapshot-ului dumneavoastră';
$string['flash:success_saving'] = 'Snapshot salvat!!!';
$string['flash:text_make_snapshot'] = 'Salvează snapshot';
$string['flash:text_result_field'] = 'Rezultatele dumneavoastră';
$string['flash:textselectdevice'] = 'Vă rugam să selectați aparatul';
$string['installflash'] = 'Vă rugăm să instalați flash';
$string['makesnapshot'] = 'Faceți Snapshot';
$string['mfavatar:view'] = 'Vezi Mfavatar';
$string['pluginname'] = 'Avatar MoodleFreak';
$string['pluginname_desc'] = 'Particularizați avatarul MoodleFreak mai jos';
$string['privacy:null_reason'] = 'Nu există date colectate de acest plugin.';
$string['returntoprofile'] = 'Înapoi la profilul dumneavoastră';
$string['snapshotpage'] = 'Snapshot';
$string['task:update_avatars'] = 'Actualizează avatarurile utilizatorului';
