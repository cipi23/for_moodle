<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'block_microsoft', language 'ro', version '3.9'.
 *
 * @package     block_microsoft
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['connecttoo365'] = 'Conectare la Microsoft 365';
$string['contactadmin'] = 'Contactați administratorul pentru mai multe informații.';
$string['course_feature_calendar'] = 'Calendar Outlook';
$string['course_feature_team'] = 'Echipă';
$string['course_sync_option_not_synced'] = 'Nesincronizat';
$string['defaultprofile'] = 'Imagine de profil';
$string['geto365'] = 'Instalați Office';
$string['groupsnotenabledforcourse'] = 'Office Groups nu este activat penrtu acest grup';
$string['linkdocsdotcom'] = 'My Docs.com';
$string['linkemail'] = 'Email-ul meu';
$string['linkonenote'] = 'Moodle OneNote notebook';
$string['linkonenote_unavailable'] = 'OneNote nedisponibil';
$string['linkoutlook'] = '';
$string['linkprefs'] = 'Editează setări';
$string['logintoo365'] = 'Autentificați-vă în Office&nbsp;365';
$string['microsoft'] = 'Microsoft';
$string['microsoft:addinstance'] = 'Adăugați un nou block Microsoft';
$string['microsoft:managegroups'] = 'Permiteți abilitatea de a administra grupurile';
$string['microsoft:myaddinstance'] = 'Adăugați un nou block Microsoft pe pagina mea Moodle';
$string['msalogin'] = 'Autentificați-vă cu Microsoft Account';
$string['notebookname'] = 'Moodle Notebook';
$string['pluginname'] = 'Block Microsoft';
$string['settings_showdocsdotcom'] = 'Afișați "My Docs.com"';
$string['settings_showemail'] = 'Afișați "My Email"';
$string['settings_showmyforms'] = '"My Forms"';
$string['settings_showmyforms_default'] = 'https://forms.office.com/Pages/DesignPage.aspx#';
$string['settings_showo365connect'] = 'Afișați "Connect to Office 365"';
$string['settings_showonedrive'] = 'Afișează "My OneDrive"';
$string['settings_showpreferences'] = 'Afișați "Editați setările"';
