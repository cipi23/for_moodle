<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'block_mootivated', language 'ro', version '3.9'.
 *
 * @package     block_mootivated
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['anonngroup'] = 'Altă secțiune';
$string['auction'] = 'Licitație';
$string['buy'] = 'Cumpără acum';
$string['configheader'] = 'Setări';
$string['configtitle'] = 'Titlu';
$string['confirmpurchase'] = 'Vă rugăm să confirmați';
$string['contentsaved'] = 'Conținut salvat.';
$string['continuebrowsing'] = 'Continuă cumpărările';
$string['defaulttitle'] = 'Mootivated';
$string['history'] = 'Activitate recentă';
$string['infopagecontent'] = 'Conținutul paginii';
$string['infopagetitle'] = 'Informații';
$string['lessthan1min'] = '<1min';
$string['mobilelogin'] = 'Mobil';
$string['mootivated:addinstance'] = 'Se adaugă un nou block Mootivated';
$string['mootivated:myaddinstance'] = 'Se adaugă block-ul Mootivated pe dashboard';
$string['mootivated:view'] = 'Se vizualizează conținutul block-ului Mootivated';
$string['name'] = 'Nume';
$string['ncoins'] = '{$a} monedă(e)';
$string['nremaining'] = '{$a} rămase';
$string['pleasewait'] = 'Vă rugăm să așteptați';
$string['pluginname'] = 'Mootivated';
$string['quantity'] = 'Cantitate';
$string['timeleft'] = '{$a} rămase';
$string['tinydays'] = '{$a}d';
$string['tinyhours'] = '{$a}h';
$string['tinymin'] = '{$a}min';
$string['total'] = 'Total';
$string['totalcost'] = 'Costul total';
$string['unitcost'] = 'Cost';
$string['updatequantities'] = 'Actualizați cantitățile';
$string['winchances'] = '{$a}% șansă de câștig';
