<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'block_myoverview', language 'ro', version '3.9'.
 *
 * @package     block_myoverview
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['addtofavourites'] = 'Setați acest curs ca favorit';
$string['all'] = 'Toate cursurile (cu excepția celor eliminate din vizualizare)';
$string['allincludinghidden'] = 'Toate';
$string['aria:addtofavourites'] = 'Adaugă la favorite';
$string['aria:allcourses'] = 'Afișați toate cursurile, cu excepția cursurilor eliminate din vizualizare';
$string['aria:allcoursesincludinghidden'] = 'Afișați toate cursurile';
$string['aria:card'] = 'Treceți la vizualizarea de tip card';
$string['aria:controls'] = 'Controale de prezentare generală a cursurilor';
$string['aria:courseactions'] = 'Acțiuni pentru cursul curent';
$string['aria:courseprogress'] = 'Progres în curs:';
$string['aria:coursesummary'] = 'Text rezumativ curs:';
$string['aria:customfield'] = 'Afișează {$a} cursuri';
$string['aria:displaydropdown'] = 'Afișați meniul derulant';
$string['aria:favourites'] = 'Afișează cursurile favorite';
$string['aria:future'] = 'Afișează cursurile viitoare';
$string['aria:groupingdropdown'] = 'Grupare meniu derulant';
$string['aria:hiddencourses'] = 'Afișați cursurile eliminate din vizualizare';
$string['aria:hidecourse'] = 'Eliminați {$a} din vizualizare';
$string['aria:inprogress'] = 'Afișați cursurile în progres';
$string['aria:lastaccessed'] = 'Sortați cursurile după ultima dată de accesare';
$string['aria:list'] = 'Treceți la vizualizarea tip listă';
$string['aria:past'] = 'Afișează cursurile din trecut';
$string['aria:removefromfavourites'] = 'Eliminați cursul din favorite';
$string['aria:shortname'] = 'Sortați cursurile după numele scurt al cursului';
$string['aria:showcourse'] = 'Restaurează {$a} pentru a vizualiza';
$string['aria:sortingdropdown'] = 'Meniul derulant de sortare';
$string['aria:summary'] = 'Treceți la vizualizarea de tip rezumat';
$string['aria:title'] = 'Sortați cursurile după numele cursului';
$string['availablegroupings'] = 'Filtre disponibile';
$string['availablegroupings_desc'] = 'Filtre de curs care sunt disponibile pentru selectare de către utilizatori. Dacă nu este selectat niciunul, vor fi afișate toate cursurile.';
$string['card'] = 'Card';
$string['cards'] = 'Carduri';
$string['complete'] = 'complet';
$string['completepercent'] = '{$a}% complet';
$string['courseprogress'] = 'Progres curs:';
$string['customfield'] = 'Câmp personalizat';
$string['customfiltergrouping'] = 'Câmp de utilizat';
$string['customfiltergrouping_nofields'] = 'Această opțiune necesită configurarea unui câmp personalizat al cursului și vizibil pentru toată lumea.';
$string['defaulttab'] = 'Tab implicit';
$string['displaycategories'] = 'Afișează categorii';
$string['displaycategories_help'] = 'Afișați categoria cursului pe elementele cursului din tabloul de bord, de tip card, de tip listă sau de tip sumar curs.';
$string['favourites'] = 'Favorit';
$string['future'] = 'Viitoare';
$string['hidden'] = 'Cursuri eliminate din vizualizare';
$string['hiddencourses'] = 'Cursuri eliminate din vizualizare';
$string['hidecourse'] = 'Eliminați din vizualizare';
$string['inprogress'] = 'În desfășurare';
$string['lastaccessed'] = 'Accesat ultima dată';
$string['layouts'] = 'Aspecte de curs disponibile';
$string['layouts_help'] = 'Tipuri de aspecte generale ale cursului, care sunt disponibile pentru selectare de către utilizatori. Dacă nu este selectat niciunul, va fi utilizat aspectul de tip card.';
$string['list'] = 'Listă';
$string['morecourses'] = 'Mai multe cursuri';
$string['myoverview:myaddinstance'] = 'Adaugă un nou block Cursurile mele în Dashboard';
$string['next30days'] = 'Următoarele 30 de zile';
$string['next7days'] = 'Următoarele 7 zile';
$string['nocourses'] = 'Nu există cursuri';
$string['nocoursesfuture'] = 'Nu există cursuri viitoare';
$string['nocoursesinprogress'] = 'Nu există cursuri în desfășurare';
$string['nocoursespast'] = 'Nu există cursuri anterioare';
$string['nocustomvalue'] = 'Nu {$a}';
$string['past'] = 'În trecut';
$string['pluginname'] = 'Cursurile mele';
$string['privacy:metadata:overviewgroupingpreference'] = 'Preferințe de grupare a blocului de afișare a cursurilor';
$string['privacy:metadata:overviewpagingpreference'] = 'Preferințe de paginare a blocului de afișare a cursurilor';
$string['privacy:metadata:overviewsortpreference'] = 'Preferințe de sortare a blocului de afișare a cursurilor';
$string['privacy:metadata:overviewviewpreference'] = 'Preferințe de vizualizared a blocului de afișare a cursurilor';
$string['privacy:request:preference:set'] = 'Valoarea setării \'{$a->name}\' a fost {$a->value}\'';
$string['removefromfavourites'] = 'Scoate acest curs de la favorite';
$string['shortname'] = 'Nume prescurtat';
$string['show'] = 'Restabiliți vizualizarea';
$string['sortbycourses'] = 'Sortează după cursuri';
$string['sortbydates'] = 'Sortează după date';
$string['summary'] = 'Rezumat';
$string['timeline'] = 'Timeline';
$string['title'] = 'Numele cursului';
$string['viewcourse'] = 'Vezi cursul';
$string['viewcoursename'] = 'Vezi cursul {$a}';
