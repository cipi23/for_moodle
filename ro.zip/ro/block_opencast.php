<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'block_opencast', language 'ro', version '3.9'.
 *
 * @package     block_opencast
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['aclrolesname'] = 'Roluri';
$string['addrole'] = 'Adaugă un rol nou';
$string['addvideo'] = 'Adaugă video';
$string['appearance_overview_settingshowlocation'] = 'Afișează locația';
$string['changevisibility_header'] = 'Modifică vizibilitatea pentru {$a->title}';
$string['created'] = 'Creat de';
$string['createdby'] = 'Încărcat de';
$string['deleteaclgroup'] = 'Șterge video din listă';
$string['description'] = 'Descriere';
$string['duration'] = 'Durată';
$string['erroremailbody'] = '{$a->errorstr} Detalii: {$a->message}.';
$string['exists_catalogname'] = 'Câmpul există deja';
$string['groupcreation'] = 'Creează un grup';
$string['haction'] = 'Acțiune';
$string['heading_actions'] = 'Acțiuni';
$string['heading_delete'] = 'Șterge';
$string['heading_permanent'] = 'Permanent';
$string['heading_position'] = 'Poziție';
$string['heading_required'] = 'Necesar';
$string['heading_role'] = 'Rol';
$string['hlocation'] = 'Locație';
$string['hpublished'] = 'Publicat';
$string['htitle'] = 'Titlu';
$string['hvisibility'] = 'Vizibilitate';
$string['hworkflow_state'] = 'Status';
$string['license'] = 'Licență';
$string['limitvideos'] = 'Numărul de video-uri';
$string['location'] = 'Locație';
$string['metadata'] = 'Metadata';
$string['mstatecreatingevent'] = 'Se încarcă...';
$string['notpublished'] = 'Nepublicat';
$string['rights'] = 'Drepturi';
$string['rightsHolder'] = 'Drepturi';
$string['seriesidnotvalid'] = 'Seria nu există';
$string['setting_permanent'] = 'este permanent';
$string['source'] = 'Sursă';
$string['subjects'] = 'Subiecte';
