<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'block_people', language 'ro', version '3.9'.
 *
 * @package     block_people
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['noparticipantslist'] = 'Nu vă este permis să vedeți lista participanților la acest curs';
$string['participantslist'] = 'Afișați lista participanților';
$string['people:addinstance'] = 'Adăugați un nou block people';
$string['people:myaddinstance'] = 'Adăugați un nou block people în Dashboard';
$string['pluginname'] = 'People';
$string['setting_hideblock'] = 'Se ascunde block-ul';
$string['setting_hideblockheading'] = 'Se ascunde block-ul';
$string['setting_multipleroles'] = 'Afișează rolurile multiple';
$string['setting_resetvisibility'] = 'Resetează vizibilitatea';
$string['setting_roles'] = 'Afișează aceste roluri';
$string['setting_roles_desc'] = 'Prin această setare, puteți decide ce utilizatori apar în acest block. Utilizatorii trebuie să aibă cel puțin unul din aceste roluri într-un curs pentru ca numele lor să fie afișat în block.';
$string['setting_rolesheading'] = 'Roluri';
