<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'block_point_view', language 'ro', version '3.9'.
 *
 * @package     block_point_view
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['choice'] = 'Opțiuni';
$string['colmodule'] = 'Modul';
$string['colsection'] = 'Secțiune';
$string['disable_type'] = 'Dezactivați toate';
$string['enable_type'] = 'Activați toate';
$string['enableall'] = 'Activați tot în <b>{$a}</b>';
$string['export_title_tab'] = 'Export';
$string['exportxls'] = 'Export XLS';
$string['folder'] = 'Foldere';
$string['forum'] = 'Forumuri';
$string['hsuforum'] = 'Forumuri HSU';
$string['lesson'] = 'Lecții';
$string['no'] = 'Nu';
$string['no_activities_config_message'] = 'Nu există activitate';
$string['noneactivity'] = 'Nu există activitate';
$string['page'] = 'Pagini';
$string['point_viewpix'] = 'Emojis';
$string['resource'] = 'Fișiere';
$string['yes'] = 'Da';
