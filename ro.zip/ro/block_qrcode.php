<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'block_qrcode', language 'ro', version '3.9'.
 *
 * @package     block_qrcode
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['button'] = 'Descarcă';
$string['filename'] = 'curs';
$string['formats'] = 'Format';
$string['img_tag_alt'] = 'Cod QR';
$string['instc_uselogo'] = 'Utilizați logo';
$string['logofile_png'] = 'Alegeți logo-ul .png';
$string['logofile_svg'] = 'Alegeți logo-ul .svg';
$string['pluginname'] = 'Cod QR';
$string['settings'] = 'Setări QR code';
$string['sizes'] = 'Dimensiune';
$string['submit'] = 'Salvează modificările';
$string['use_logo'] = 'Utilizați logo';
$string['usedefault'] = 'Utilizați setările implicite';
