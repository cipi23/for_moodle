<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'block_studentstracker', language 'ro', version '3.9'.
 *
 * @package     block_studentstracker
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['blocktitle'] = 'Titlul block-ului';
$string['color_never_desc'] = 'Culoarea utilizatorului care nu a accesat niciodată cursul.';
$string['date_asc'] = 'Data în mod crescător';
$string['date_desc'] = 'Data în mod descrescător';
$string['excludeolder'] = 'Exclude rezultatele mai vechi de n zile';
$string['footer'] = 'Text în subsolul paginii';
$string['nogroups'] = 'Niciunul (toți utilizatorii)';
$string['roles'] = 'Roluri care au permisiunea de a vedea block-ul';
$string['roleview'] = 'Roluri care au permisiunea de e vedea block-ul';
$string['text_footer_content'] = 'Contactați-i!';
$string['text_header'] = 'utilizatori absenți';
$string['text_header_fine'] = 'Totul este în regulă!';
$string['text_never_content'] = 'fără acces';
$string['truncate'] = 'Afișați doar n rezultate';
