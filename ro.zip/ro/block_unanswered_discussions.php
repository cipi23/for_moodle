<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'block_unanswered_discussions', language 'ro', version '3.9'.
 *
 * @package     block_unanswered_discussions
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['config_show'] = 'Se afișează diferite discuții fără răspuns';
$string['config_show_help'] = '<p>Prin această setare, puteți controla dacă utilizatorul va vedea:</p><ul>
        <li>discuții fără răspuns începute de utilizatorulul însuși,</li>
        <li>discuții fără răspuns începute de către alții, care au cea mai îndelungată perioadă fără răspuns, și/sau</li>
         <li>discuții fără răspuns aleatorii începute de alții (și care nu sunt încă afișate în block)</li>
</ul>
<p>Cantitatea de discuții din fiecare tip poate fi specificată printr-un număr.</p>
<p>Pentru a dezactiva un tip de mesaj, setați numărul mesajelor afișate la Nici unul.</p>';
$string['excludefora'] = 'Formuri excluse';
$string['noforatoexclude'] = 'Nu există forumuri de exclus';
$string['none'] = 'Nici unul';
$string['nounanswereddiscussions'] = 'Nu există discuții fără răspuns';
$string['oldestposts'] = 'Cele mai vechi discuții';
$string['pluginname'] = 'Discuții fără răspuns';
$string['randomposts'] = 'Discuții aleatoare';
$string['show'] = 'Afișează';
$string['unanswered_discussions:addinstance'] = 'Adaugă un nou block Discuții fără răspuns';
$string['unanswereddiscussions'] = 'Discuții fără răspuns';
$string['yourposts'] = 'Discuțiile dumneavoastră';
$string['yourpostsconfig'] = 'Discuțiile utilizatorului';
