<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'block_xp', language 'ro', version '3.9'.
 *
 * @package     block_xp
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['activityoresourceis'] = 'Activitatea sau resursa este {$a}';
$string['addacondition'] = 'Adaugă o condiție';
$string['addarule'] = 'Adaugă o regulă';
$string['addrulesformhelp'] = 'Ultima coloană definește numărul de puncte de experiență câștigate atunci când este îndeplinit criteriul.';
$string['anonymity'] = 'Anonimat';
$string['anonymity_help'] = 'Această setare controlează dacă participanții pot vedea numele și avatarul celorlalți utilizatori.';
$string['awardaxpwhen'] = '<strong>{$a}</strong> punctele de experiență sunt câștigate când:';
$string['basexp'] = 'Baza algoritmului';
$string['cachedef_ruleevent_eventslist'] = 'Lista cu unele evenimente';
$string['coefxp'] = 'Coeficientul algoritmului';
$string['colon'] = '{$a->a}: {$a->b}';
$string['configheader'] = 'Setări';
$string['configtitle'] = 'Titlu';
$string['congratulationsyouleveledup'] = 'Felicitări!';
$string['coursereport'] = 'Raportul cursului';
$string['courserules'] = 'Regulile cursului';
$string['coursesettings'] = 'Setările cursului';
$string['customizelevels'] = 'Particularizează nivelurile';
$string['defaultrules'] = 'Reguli implicite';
$string['deletecondition'] = 'Elimină condiția';
$string['deleterule'] = 'Elimină regula';
$string['description'] = 'Descriere';
$string['displaynneighbours'] = 'Afișează {$a} vecini';
$string['displayoneneigbour'] = 'Afișează un vecin';
$string['displayparticipantsidentity'] = 'Afișează identitatea participanților';
$string['enableinfos'] = 'activați pagina cu informații';
$string['enableinfos_help'] = 'Când este setat la "Nu", cursanții nu vor putea vedea pagina cu informații.';
$string['enablelogging'] = 'Activați jurnalizarea';
$string['errorlevelsincorrect'] = 'Numărul minim de niveluri este 2';
$string['errorunknownevent'] = 'Eroare: eveniment necunoscut';
$string['errorunknownmodule'] = 'Eroare: modul necunoscut';
$string['event_user_leveledup'] = 'Utilizatorul a trecut la nivelul următor';
$string['eventis'] = 'Evenimentul este {$a}';
$string['eventname'] = 'Numele evenimentului';
$string['eventproperty'] = 'Proprietatea evenimentului';
$string['for1day'] = 'Pentru o zi';
$string['for1month'] = 'Pentru o lună';
$string['for1week'] = 'Pentru o săptămână';
$string['for3days'] = 'Pentru 3 zile';
$string['forever'] = 'Întotdeauna';
$string['forthewholesite'] = 'Pentru întregul site';
$string['hideparticipantsidentity'] = 'Ascunde identitatea participanților';
$string['incourses'] = 'În cursuri';
$string['infos'] = 'Informații';
$string['level'] = 'Nivel';
$string['leveldesc'] = 'Descrierea nivelului';
$string['levels'] = 'Niveluri';
$string['levelup'] = 'Ați trecut la nivelul următor!';
$string['levelx'] = 'Nivel #{$a}';
$string['logging'] = 'Jurnalizare';
$string['navinfos'] = 'Informații';
$string['navlevels'] = 'Niveluri';
$string['navlog'] = 'Jurnal';
$string['navreport'] = 'Raport';
$string['navrules'] = 'Reguli';
$string['navsettings'] = 'Setări';
$string['pluginname'] = 'Ați trecut la următorul nivel!';
$string['progress'] = 'Progres';
$string['property:component'] = 'Componenta evenimentului';
$string['property:crud'] = 'Eveniment CRUD';
$string['property:eventname'] = 'Numele evenimentului';
$string['resetcoursedata'] = 'Resetați datele cursului';
$string['resetgroupdata'] = 'Resetați datele grupului';
$string['rule'] = 'Regulă';
$string['rule:contains'] = 'conține';
$string['rule:eq'] = 'este egală cu';
$string['rule:eqs'] = 'este strict egală cu';
$string['rule:gt'] = 'este mai mare decât';
$string['rule:gte'] = 'este mai mare sau egală cu';
$string['rule:lt'] = 'este mai mică decât';
$string['rule:lte'] = 'este mai mică sau egală cu';
$string['rulecm'] = 'Activitatea sau resursa';
$string['rulecmdesc'] = 'Activitatea sau resursa este \'{$a->contextname}\'.';
$string['ruleevent'] = 'Eveniment specific';
$string['ruleeventdesc'] = 'Evenimentul este \'{$a->eventname}';
$string['ruleproperty'] = 'Proprietatea evenimentului';
$string['rulepropertydesc'] = 'Proprietatea \'{$a->property}\' {$a->compare} \'{$a->value}\'.';
$string['ruleset'] = 'Setul de condiții';
$string['ruleset:all'] = 'TOATE condițiile sunt adevărate';
$string['ruleset:any'] = 'ORICARE dintre condiții este adevărată';
$string['ruleset:none'] = 'NICIUNA dintre condiții nu este adevărată';
$string['someoneelse'] = 'Altcineva';
$string['timebetweensameactions'] = 'Timpul necesar între acțiuni identice';
$string['updateandpreview'] = 'Actualizare ș previzualizare';
$string['usealgo'] = 'Utilizează algoritmul';
$string['usecustomlevelbadges_help'] = 'Atunci când este setat Da, trebuie să furnizați o imagine pentru fiecare nivel.';
$string['value'] = 'Valoare';
$string['valuessaved'] = 'Valorile au fost salvate cu succes';
$string['when'] = 'Când';
$string['wherearexpused'] = 'Unde se utilizează punctele de experiență?';
$string['xp'] = 'Puncte de experiență';
$string['xp:addinstance'] = 'Se adaugă un nou block XP';
$string['xp:earnxp'] = 'Se obțin puncte de experiență';
$string['xp:myaddinstance'] = 'Adaugă block-ul la dashboardul meu';
$string['xp:view'] = 'Vezi block-ul și paginile corelate';
$string['youreachedlevela'] = 'Ați ajuns la nivelul {$a}!';
$string['yourownrules'] = 'Propriile dumneavoastră reguli';
