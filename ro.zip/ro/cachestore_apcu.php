<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'cachestore_apcu', language 'ro', version '3.9'.
 *
 * @package     cachestore_apcu
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['clusternotice'] = 'Vă rugăm să luați în considerare faptul că APCu este o alegere corespunzătoare doar pentru site-urile single node sau memoriile cache care pot fi stocate local.
Pentru mai multe informații, vedeți <a href="{$a}">APC documentația utilizatorului cache</a>.';
$string['notice'] = 'Notificare';
$string['pluginname'] = 'Utilizator cache APC (APCu)';
$string['prefix'] = 'Prefix';
$string['prefix_help'] = 'Prefixul de mai sus se folosește pentru toate cheile stocate în această instanță de magazin APC. În mod implicit, este utilizat prefixul bazei de date.';
$string['prefixinvalid'] = 'Prefixul pe care l-ați selectat nu este valid. Puteți folosi doar a-z A-Z 0-9-_.';
$string['prefixnotunique'] = 'Prefixul pe care l-ați selectat nu este unic. Vă rugăm să alegeți un prefix unic.';
$string['privacy:metadata'] = 'Pluginul APCu cache utilizator (APCu) stochează datele pentru scurt timp ca parte a funcționalității sale de cache, dar aceste date sunt șterse în mod regulat și nu sunt trimise în niciun fel extern.';
$string['testperformance'] = 'Test de performanță';
$string['testperformance_desc'] = 'Dacă este activat, performanța APCu va fi inclusă la vizualizarea paginii cu performanța testului. Nu este recomandată activarea la un site de producție.';
