<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'cado', language 'ro', version '3.9'.
 *
 * @package     cado
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['activityoptions'] = 'Activități de inclus';
$string['approveagree'] = 'Aprobă CADO';
$string['approvelink'] = 'Aprobă?';
$string['approvereport'] = 'Aprobă acest CADO';
$string['approvesubjectline'] = 'CADO aprobat:';
$string['cado'] = 'CADO';
$string['cado:generate'] = 'Generați un nou CADO';
$string['compareheader'] = 'Rezultatul comparației';
$string['comparemissing'] = 'LIPSEȘTE:';
$string['course'] = 'Inserați codul cursului';
$string['courseinstruction'] = 'Selectează CADO';
$string['eventapprovecado'] = 'CADO aprobat';
$string['eventnotapprovecado'] = 'CADO neaprobat';
$string['general'] = 'General';
$string['inchidden'] = 'Afișați activități ascunse:';
$string['minutes'] = '(minute)';
$string['modulename'] = 'Raport CADO';
$string['modulenameplural'] = 'Rapoarte CADO';
$string['nameinstruction'] = 'Filtrați pe baza denumirii prescurtate a cursului';
$string['notapplicable'] = 'Nesetat';
$string['notapprovesubjectline'] = 'CADO neaprobat:';
$string['privacy:nothing'] = 'Necompletat:';
$string['quiz'] = 'Teste';
$string['section'] = 'Secțiune';
$string['semester'] = 'Semestru';
$string['settings'] = 'Setări CADO';
$string['summary'] = 'Descrierea cursului';
$string['topic'] = 'Topic';
$string['update'] = 'Actualizează:';
$string['useranonymous'] = 'Anonim';
