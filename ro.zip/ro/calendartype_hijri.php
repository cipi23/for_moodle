<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'calendartype_hijri', language 'ro', version '3.9'.
 *
 * @package     calendartype_hijri
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['algorithm'] = 'Algoritm de conversie';
$string['algorithm1'] = 'Algoritmul A';
$string['algorithm2'] = 'Algoritmul B';
$string['am'] = 'am';
$string['am_caps'] = 'AM';
$string['configalgorithm'] = 'Diferite țări islamice folosesc algoritmi diferiți pentru a-și converti datele Gregoriene și Hijri. De exemplu, în unele țări, 12<sup>th</sup> Mai 2012 este echivalent cu 20<sup>th</sup> umada Alaker (Algoritm A) iar în alte țări este echivalent cu 21<sup>st</sup> Jumada Alaker (Algoritm B).';
$string['month1'] = 'Muḥarram';
$string['month10'] = 'Shawwāl';
$string['month11'] = 'Dhū al-Qaʿda';
$string['month12'] = 'Dhū al-Ḥijja';
$string['month2'] = 'Ṣafar';
$string['month3'] = 'Rabīʿ al-Awwal';
$string['month4'] = 'Rabīʿ al-Thānī';
$string['month5'] = 'Jumādā al-Ūlā';
$string['month6'] = 'Jumādā al-Thānī';
$string['month7'] = 'Rajab';
$string['month8'] = 'Shaʿbān';
$string['month9'] = 'Ramaḍān';
$string['name'] = 'Hijri';
$string['pluginname'] = 'Tipul de calendar Hijri';
$string['pm'] = 'pm';
$string['pm_caps'] = 'PM';
$string['wday0'] = 'Du';
$string['wday1'] = 'Lu';
$string['wday2'] = 'Ma';
$string['wday3'] = 'Mie';
$string['wday4'] = 'Joi';
$string['wday5'] = 'Vin';
$string['wday6'] = 'Sâm';
$string['weekday0'] = 'Duminică';
$string['weekday1'] = 'Luni';
$string['weekday2'] = 'Marți';
$string['weekday3'] = 'Miercuri';
$string['weekday4'] = 'Joi';
$string['weekday5'] = 'Vineri';
$string['weekday6'] = 'Sâmbătă';
