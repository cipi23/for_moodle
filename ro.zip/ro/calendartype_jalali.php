<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'calendartype_jalali', language 'ro', version '3.9'.
 *
 * @package     calendartype_jalali
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['am'] = 'am';
$string['am_caps'] = 'AM';
$string['month1'] = 'Farvardin';
$string['month10'] = 'Dey';
$string['month11'] = 'Bahman';
$string['month12'] = 'Esfand';
$string['month2'] = 'Ordibehesht';
$string['month3'] = 'Khordad';
$string['month4'] = 'Tir';
$string['month5'] = 'Mordad';
$string['month6'] = 'Shahrivar';
$string['month7'] = 'Mehr';
$string['month8'] = 'Aban';
$string['month9'] = 'Azar';
$string['name'] = 'Persian';
$string['pluginname'] = 'Tip de calendar persan';
$string['pm'] = 'pm';
$string['pm_caps'] = 'PM';
$string['wday0'] = 'Du';
$string['wday1'] = 'Lu';
$string['wday2'] = 'Mar';
$string['wday3'] = 'Mie';
$string['wday4'] = 'Joi';
$string['wday5'] = 'Vin';
$string['wday6'] = 'Sâm';
$string['weekday0'] = 'Dum';
$string['weekday1'] = 'Luni';
$string['weekday2'] = 'Marți';
$string['weekday3'] = 'Miercuri';
$string['weekday4'] = 'Joi';
$string['weekday5'] = 'Vineri';
$string['weekday6'] = 'Sâmbătă';
