<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'calendartype_japanese', language 'ro', version '3.9'.
 *
 * @package     calendartype_japanese
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['am'] = 'am';
$string['configjapaneseyeartype'] = 'Alegeți dintre tipul de an gregorian sau regula Împăratului.';
$string['emperor'] = 'Empiric';
$string['gregorian'] = 'Gregorian';
$string['heisei'] = 'An Heisei {$a}';
$string['japaneseyeartype'] = 'Tipul de an japonez';
$string['meiji'] = 'An Meiji {$a}';
$string['meijihandover'] = 'An Meiji {$a->old} - An Taishou {$a->new}';
$string['month'] = '{$a}';
$string['name'] = 'Japonez';
$string['pluginname'] = 'Tipul de calendar japonez';
$string['pm'] = 'pm';
$string['shouwa'] = 'An Shouwa {$a}';
$string['shouwahandover'] = 'An Shouwa {$a->old} - An Heisei {$a->new}';
$string['taishou'] = 'An Taishou {$a}';
$string['taishouhandover'] = 'An Taishou {$a->old} - An Shouwa {$a->new}';
$string['year'] = 'an';
