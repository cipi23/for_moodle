<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'capquiz', language 'ro', version '3.9'.
 *
 * @package     capquiz
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['action'] = 'Acțiune';
$string['add_a_quiz_question'] = 'Adaugă o întrebare în listă';
$string['attempt'] = 'Încercare';
$string['attempts'] = 'Încercări';
$string['author'] = 'Autor';
$string['available_questions'] = 'Întrebări disponibile';
$string['chronological'] = 'Cronologic';
$string['configure'] = 'Configurează';
$string['configure_capquiz'] = 'Configurați CAPQuiz';
$string['created'] = 'Creat';
$string['dashboard'] = 'Dashboard';
$string['description'] = 'Descriere';
$string['firstname'] = 'Prenume';
$string['hideshow'] = 'Ascunde/Afișează';
$string['import'] = 'Import';
$string['lastname'] = 'Nume de familie';
$string['modulename'] = 'CAPQuiz';
$string['modulenameplural'] = 'CAPQuizzes';
$string['name'] = 'Nume';
$string['need_to_log_in'] = 'Trebuie să vă autentificați';
$string['no_enrolled_students'] = 'Nu există cursanți înscriși';
$string['no_questions'] = 'Nu există întrebări';
$string['no_questions_added_to_list'] = 'Nu s-au adăugat întrebări la listă';
$string['no_templates_created'] = 'Nu au fost create șabloane';
$string['not_published'] = 'Nepublicat';
$string['pluginadministration'] = 'Administrare CAPQuiz';
$string['pluginname'] = 'CAPQuiz';
$string['publish'] = 'Publică';
$string['published'] = 'Publică';
$string['questions'] = 'Întrebări';
$string['report'] = 'raport';
$string['reports'] = 'Raportul';
$string['select'] = 'Selectează';
$string['settings'] = 'Setări CAPQuiz';
$string['status'] = 'Status';
$string['strftimedatetimeseconds'] = '%d %B %Y, %I:%M:%S %p';
$string['subplugintype_capquizreport'] = 'Raport';
$string['subplugintype_capquizreport_plural'] = 'Rapoarte';
$string['template'] = 'Șablon';
$string['title'] = 'Titlu';
$string['true'] = 'Adevărat';
$string['username'] = 'Nume de utilizator';
