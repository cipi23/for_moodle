<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'customfield_text', language 'ro', version '3.9'.
 *
 * @package     customfield_text
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['displaysize'] = 'Dimensiunea câmpului';
$string['errorconfigdisplaysize'] = 'Dimensiunea câmpului trebuie să aibă între 1 și 200 de caractere.';
$string['errorconfiglinkplaceholder'] = 'Linkul trebuie să conțină un substituent $$.';
$string['errorconfiglinksyntax'] = 'Linkul trebuie să fie o adresă URL validă, începând cu http:// sau https://.';
$string['errorconfigmaxlen'] = 'Numărul maxim de caractere permis trebuie să fie între 1 și 1333.';
$string['errormaxlength'] = 'Numărul maxim de caractere permis în acest câmp este de {$a}.';
$string['islink'] = 'Câmp legătură';
$string['islink_help'] = 'Pentru a transforma textul într-un link, introduceți un URL care conține $$ ca substituent, unde $$ va fi înlocuit cu textul. De exemplu, pentru a transforma un ID Twitter într-un link, introduceți https://twitter.com/$$.';
$string['ispassword'] = 'Câmpul de parolă';
$string['linktarget'] = 'Țintă legăturii';
$string['maxlength'] = 'Număr maxim de caractere';
$string['newwindow'] = 'Fereastră nouă';
$string['none'] = 'Niciunul';
$string['pluginname'] = 'Text scurt';
$string['privacy:metadata'] = 'Pluginul de tip câmp text scurt nu stochează date personale; folosește tabele definite în nucleu.';
$string['sameframe'] = 'Același cadru';
$string['samewindow'] = 'Aceeași fereastră';
$string['specificsettings'] = 'Setări scurte ale câmpului de text';
