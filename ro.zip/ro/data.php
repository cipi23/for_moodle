<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'data', language 'ro', version '3.9'.
 *
 * @package     data
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['action'] = 'Acţiune';
$string['add'] = 'Adaugă un articol';
$string['addcomment'] = 'Adaugă comentariu';
$string['addentries'] = 'Adaugă articole';
$string['addtemplate'] = 'Adaugă şablon';
$string['advancedsearch'] = 'Căutare complexă';
$string['allowcomments'] = 'Permite comentarii la intrări';
$string['alttext'] = 'Text alternativ';
$string['approvalstatus'] = 'Starea aprobării';
$string['approve'] = 'Aprobă';
$string['approved'] = 'Aprobat';
$string['areacontent'] = 'Câmpuri';
$string['ascending'] = 'Crescător';
$string['asearchtemplate'] = 'Şablon căutare complexă';
$string['atmaxentry'] = 'Aţi adăugat numărul maxim de articole permis!';
$string['authorfirstname'] = 'Prenume autor';
$string['authorlastname'] = 'Nume autor';
$string['autogenallforms'] = 'Generează toate şabloanele implicite';
$string['autolinkurl'] = 'Autolink the URL';
$string['availablefromdate'] = 'Disponibil din';
$string['availabletags'] = 'Etichete disponibile';
$string['availabletags_help'] = 'Tag-urile sunt substituenţi în şablon, care vor fi înlocuiți de date sau alți itemi, cum ar fi de ex o icoană de editare, atunci când intrările sunt editate sau vizionate.

Câmpurile au formatul [[numecâmp]]. Toate celălalte tag-uri sunt de formatul ##numetag##.

Numai tag-urile care sunt în lista "Tag-uri Disponibile" pot fi folosite pentru şablonul curent.

';
$string['availabletodate'] = 'Disponibil până';
$string['availabletodatevalidation'] = 'Disponibil până în prezent nu poate fi setat înainte de disponibil de la data de.';
$string['blank'] = 'Blank';
$string['buttons'] = 'Acţiuni';
$string['bynameondate'] = 'de {$a->name} - {$a->date}';
$string['calendarend'] = '{$a} se închide';
$string['calendarstart'] = '{$a} se deschide';
$string['cancel'] = 'Anulează';
$string['cannotaccesspresentsother'] = 'Nu aveți permisiunea de a accesa presetările de la alți utilizatori';
$string['cannotadd'] = 'Nu se pot adăuga postări!';
$string['cannotdeletepreset'] = 'Eroare la ștergerea unei presetări!';
$string['cannotoverwritepreset'] = 'Eroare la suprascrierea presetării';
$string['cannotunziptopreset'] = 'Nu se poate dezarhiva directorul presetat';
$string['checkbox'] = 'Căsuţă de selecţie';
$string['chooseexportfields'] = 'Alegeţi câmpurile pe care doriţi să le exportaţi';
$string['chooseexportformat'] = 'Alegeţi formatul în care doriţi să exportaţi';
$string['chooseorupload'] = 'Selectaţi fişier';
$string['closebeforeopen'] = 'Ați specificat o dată de încheiere înainte de data de începere.';
$string['columns'] = 'coloane';
$string['comment'] = 'Comentariu';
$string['commentdeleted'] = 'Comentariu şters';
$string['commentempty'] = 'Comentariu fără conţinut';
$string['comments'] = 'Comentarii';
$string['commentsaved'] = 'Comentariu salvat';
$string['commentsn'] = '{$a} comentarii';
$string['commentsoff'] = 'Comentariile nu sunt active';
$string['completionentries'] = 'Intrări solicitate';
$string['completionentriescount'] = 'Numărul de intrări';
$string['completionentriesdesc'] = 'Numărul minim de intrări necesare: {$a}';
$string['configenablerssfeeds'] = 'Acest parametru permite activarea posibilităţii de a primi fluxuri RSS pentru toate bazele de date. Atenţie: chiar dacă aţi activat acest parametru, pentru fiecare din bazele de date va trebui să activaţi manual opţiunea "feeds".';
$string['confirmdeletefield'] = 'Sunteţi pe punctul de a şterge acest câmp, sunteţi sigur că doriţi să-l ştergeţi?';
$string['confirmdeleterecord'] = 'Sunteţi sigur că doriţi să ştergeţi acest articol?';
$string['confirmdeleterecords'] = 'Sunteți sigur(ă) că doriți să ștergeți aceste postări?';
$string['csstemplate'] = 'Şablon CSS';
$string['csvfailed'] = 'Nu s-au putut citi datele neprelucrate din fişierul CSV';
$string['csvfile'] = 'Fişier CSV';
$string['csvimport'] = 'Import fişier CSV';
$string['csvimport_help'] = 'Înregistrările pot fi importate prin intermediul unui fişier text simplu care să conțină în prima linie o serie de denumiri care definesc formatul câmpurilor din restul fișierului  apoi datele, cu o singură înregistrare pe linie, separate prin virgulă. ';
$string['csvwithselecteddelimiter'] = '<abbr title="Comma Separated Values">CSV</abbr> text cu elemente separate de virgulă';
$string['data:addinstance'] = 'Adaugă o nouă bază de date';
$string['data:approve'] = 'Aprobați și anulați intrările aprobate';
$string['data:comment'] = 'Scrie comentarii';
$string['data:exportallentries'] = 'Exportați toate intrările din baza de date';
$string['data:exportentry'] = 'Exportă o intrare din baza de date';
$string['data:exportownentry'] = 'Exportă propria postare din baza de date';
$string['data:exportuserinfo'] = 'Exportă informațiile despre utilizator';
$string['data:managecomments'] = 'Administrare comentarii';
$string['data:manageentries'] = 'Administrare articole';
$string['data:managetemplates'] = 'Administrare şabloane';
$string['data:manageuserpresets'] = 'Administrare setări implicite pentru toate şabloanele';
$string['data:rate'] = 'Evaluează articole';
$string['data:readentry'] = 'Citeşte articole';
$string['data:view'] = 'Vezi activitatea din baza de date';
$string['data:viewallratings'] = 'Vedeți toate evaluările brute acordate de alte persoane';
$string['data:viewalluserpresets'] = 'Vezi parametri impliciţi de la toţi utilizatorii';
$string['data:viewanyrating'] = 'Vedeți evaluările totale pe care le-a primit oricine';
$string['data:viewentry'] = 'Vizualizează articole';
$string['data:viewrating'] = 'Vedeți evaluarea totală pe care ați primit-o';
$string['data:writeentry'] = 'Scrie articole';
$string['date'] = 'Data';
$string['dateentered'] = 'Data completată';
$string['defaultfielddelimiter'] = '(caracterul implicit este virgula)';
$string['defaultfieldenclosure'] = '(nu există caracter implicit)';
$string['defaultsortfield'] = 'Câmp sortare implicit';
$string['delcheck'] = 'Caseta de selectare ștergere în bloc';
$string['delete'] = 'Şterge';
$string['deleteallentries'] = 'Şterge toate articolele';
$string['deletecomment'] = 'Sunteţi sigur că doriţi ştergerea acestui comentariu?';
$string['deleted'] = 'şters';
$string['deletefield'] = 'Şterge un câmp existent';
$string['deletenotenrolled'] = 'Sunteţi sigur că doriţi ştergerea acestui parametru implicit?';
$string['deletewarning'] = 'Sunteţi sigur că doriţi să ştergeţi această valoare implicită?';
$string['descending'] = 'Descrescător';
$string['directorynotapreset'] = '{$a->directory} Nu este un parametru implicit: lipsesc fişierele: {$a->missing_files}';
$string['disapprove'] = 'Anulați aprobarea';
$string['download'] = 'Descarcă';
$string['edit'] = 'Editare';
$string['editcomment'] = 'Editează comentariu';
$string['editentry'] = 'Modifică articol';
$string['editordisable'] = 'Dezactivează editor';
$string['editorenable'] = 'Activează editor';
$string['emptyadd'] = 'Forma Adăugare şablon este goală, se generează o formă implicită...';
$string['emptyaddform'] = 'Nu aţi completat niciun câmp!';
$string['enabletemplateeditorcheck'] = 'Sigur doriți să activați editorul? Acest lucru poate duce la modificarea conținutului la salvarea șablonului.';
$string['entries'] = 'Articole';
$string['entrieslefttoadd'] = 'Pentru a finaliza această activitate trebuie să mai adăugaţi {$a->entriesleft} more entry/entries articole';
$string['entrieslefttoaddtoview'] = 'Pentru a vedea articolele postate de ceilalţi participanţi trebuie să mai adăugaţi {$a->entrieslefttoview} articole.';
$string['entry'] = 'Articol';
$string['entrysaved'] = 'Articolul postat de dumneavoastră a fost salvat.';
$string['errormustbeteacher'] = 'Pentru a putea utiliza această pagină trebuie să fiţi profesor!';
$string['errormustsupplyvalue'] = 'Trebuie să inserați o valoare aici.';
$string['errorpresetexists'] = 'Există deja o presetare cu numele selectat';
$string['eventfieldcreated'] = 'Câmp creat';
$string['eventfielddeleted'] = 'Câmp șters';
$string['eventfieldupdated'] = 'Câmp actualizat';
$string['eventrecordcreated'] = 'S-a creat înregistrarea';
$string['eventrecorddeleted'] = 'Înregistrare ștearsă';
$string['eventrecordupdated'] = 'Înregistrare actualizată';
$string['eventtemplateupdated'] = 'Șablon actualizat';
$string['eventtemplateviewed'] = 'Șabloane vizualizate';
$string['example'] = 'Exemplu modul bază de date';
$string['excel'] = 'Excel';
$string['expired'] = 'Ne pare rău, activitatea s-a închis în {$a} și nu mai este disponibilă';
$string['export'] = 'Export';
$string['exportaszip'] = 'Exportă ca zip';
$string['exportaszip_help'] = 'Exportarea ca fișier zip vă permite să salvaţi template-uri si domenii ca un zip predefinit pentru download. Fișierul zip poate fi apoi importat în alt curs.';
$string['exportedtozip'] = 'Exportat în arhivă temporară...';
$string['exportentries'] = 'Exportă postările';
$string['exportformat'] = 'Format de export';
$string['exportoptions'] = 'Opțiuni de export';
$string['exportownentries'] = 'Exportați doar propriile postări? ({$a->mine}/{$a->all})';
$string['failedpresetdelete'] = 'A intervenit o eroare la ştergerea unui parametru implicit!';
$string['fieldadded'] = 'Câmp adăugat';
$string['fieldallowautolink'] = 'Permite autolink';
$string['fielddeleted'] = 'Câmp şters';
$string['fielddelimiter'] = 'Delimitator câmp';
$string['fielddescription'] = 'Descriere câmp';
$string['fieldenclosure'] = 'Delimitare câmp';
$string['fieldheight'] = 'Înălţime';
$string['fieldheightlistview'] = 'Înălţime la vizualizarea în listă';
$string['fieldheightsingleview'] = 'Înălţime la vizualizarea individuală';
$string['fieldids'] = 'Id-uri câmp';
$string['fieldmappings'] = 'Mapări câmp';
$string['fieldmappings_help'] = 'Acest meniu vă permite să păstrați datele din baza de date existentă. Pentru a păstra datele dintr-un câmp, trebuie să le mapați la un câmp nou, unde vor apărea datele. Orice câmp poate fi, de asemenea, lăsat necompletat, fără informații copiate în el. Orice câmp vechi care nu este mapat la unul nou se va pierde și toate datele sale vor fi eliminate.
Puteți mapa doar câmpuri de același tip, astfel încât fiecare meniu derulant va conține câmpuri diferite. De asemenea, trebuie să aveți grijă să nu încercați să mapați un câmp vechi la mai multe câmpuri noi.';
$string['fieldname'] = 'Nume câmp';
$string['fieldnametype'] = '{$a->name} ({$a->type})';
$string['fieldnotmatched'] = 'Următoarele câmpuri din fişierul dumneavoastră nu sunt cunoscute în această bază de date: {$a}';
$string['fieldoptions'] = 'Opţiuni (una pe linie)';
$string['fields'] = 'Câmpuri';
$string['fieldupdated'] = 'Câmp actualizat';
$string['fieldwidth'] = 'Lăţime';
$string['fieldwidthlistview'] = 'Lăţime la vizualizarea în listă';
$string['fieldwidthsingleview'] = 'Lăţime la vizualizarea individuală';
$string['file'] = 'Fişier';
$string['fileencoding'] = 'Codare';
$string['filesnotgenerated'] = 'Nu au fost generate toate fişierele: {$a}';
$string['filtername'] = 'Conectarea automată a termenilor din baza de date';
$string['footer'] = 'Footer';
$string['forcelinkname'] = 'Nume obligatoriu pentru link';
$string['foundnorecords'] = 'Nu s-au găsit înregistrări (<a href="{$a->reseturl}">Reset filters</a>)';
$string['foundrecords'] = 'Au fost găsite următoarele înregistrări: {$a->num}/{$a->max} (<a href="{$a->reseturl}">Reset filters</a>)';
$string['fromfile'] = 'Importă din fişier zip';
$string['fromfile_help'] = 'Caracteristica care permite import-ul fișierului zip vă permite să navigați şi să încărcați un zip prestabilit de template-uri şi câmpuri de date.';
$string['generateerror'] = 'Nu sunt generate toate fișierele!';
$string['header'] = 'Header';
$string['headeraddtemplate'] = 'Definește interfața pentru adăugarea sau editarea intrărilor';
$string['headerasearchtemplate'] = 'Definește interfața pentru căutarea avansată';
$string['headercsstemplate'] = 'Defineşte stilurile CSS locale pentru alte şabloane';
$string['headerjstemplate'] = 'Definește Javascript personalizat pentru manipularea modului în care sunt afișate elementele în Listă, Single sau Adăugați șabloane';
$string['headerlisttemplate'] = 'Defineşte interfaţa de browsing pentru o serie de articole';
$string['headerrsstemplate'] = 'Defineşte modul de prezentare al articolelor din cadrul fluxurilor RSS';
$string['headersingletemplate'] = 'Defineşte interfaţa de browsing pentru un singur articol';
$string['importentries'] = 'Importă postările';
$string['importsuccess'] = 'Acest parametru implicit a fost aplicat cu succes.';
$string['includeapproval'] = 'Includeți starea de aprobare';
$string['includetags'] = 'Includeți etichete';
$string['includetime'] = 'Includeți timpul când a fost adăugat / modificat';
$string['includeuserdetails'] = 'Include informații despe utilizator';
$string['indicator:cognitivedepth'] = 'Informații cognitve despre baza de date';
$string['indicator:cognitivedepth_help'] = 'Acest indicator se bazează pe profunzimea cognitivă atinsă de cursant într-o activitate a bazei de date.';
$string['indicator:cognitivedepthdef'] = 'Informații cognitve despre baza de date';
$string['indicator:cognitivedepthdef_help'] = 'Participantul a atins acest procent din angajamentul cognitiv oferit de activitățile bazei de date în acest interval de analiză (niveluri = Fără vizualizare, Vizualizare, Trimitere)';
$string['indicator:socialbreadth'] = 'Informații sociale despre baza de date';
$string['indicator:socialbreadth_help'] = 'Acest indicator se bazează pe angajamentul social atins de cursant într-o activitate a bazei de date.';
$string['indicator:socialbreadthdef'] = 'Informații sociale despre baza de date';
$string['indicator:socialbreadthdef_help'] = 'Participantul a atins acest procent din angajamentul social oferit de activitățile bazei de date în timpul acestui interval de analiză (niveluri = Fără participare, participant doar)';
$string['insufficiententries'] = 'pentru a putea vizualiza această bază de date este nevoie de mai multe articole';
$string['intro'] = 'Descriere';
$string['invalidaccess'] = 'Această pagină nu a fost accesată în mod corect';
$string['invalidfieldid'] = 'Câmpul ID este incorect';
$string['invalidfieldname'] = 'Vă rugăm alegeţi un alt nume pentru acest câmp';
$string['invalidfieldtype'] = 'Tipul de câmp este incorect';
$string['invalidid'] = 'ID de date incorect';
$string['invalidpreset'] = '{$a} nu este o presetare.';
$string['invalidrecord'] = 'Înregistrare incorectă';
$string['invalidurl'] = 'URL-ul pe care l-aţi introdus nu este corect';
$string['jstemplate'] = 'Şablon Javascript';
$string['latitude'] = 'Latitudine';
$string['latlong'] = 'Latitudine/longitudine';
$string['latlongboth'] = 'Sunt necesare atât latitudinea, cât și longitudinea.';
$string['latlongdownloadallhint'] = 'Linkul de descărcare pentru toate articolele - KML';
$string['latlongkmllabelling'] = 'Cum se aplică etichete la elemente din cadrul fişierelor KML (Google Earth)';
$string['latlonglinkservicesdisplayed'] = 'Servicii Link-out ce vor fi afişate';
$string['latlongotherfields'] = 'Alte câmpuri';
$string['list'] = 'Afişează listă';
$string['listtemplate'] = 'Şablon listă';
$string['longitude'] = 'Longitudine';
$string['manageapproved'] = 'Permiteți editarea intrărilor aprobate';
$string['manageapproved_help'] = 'Dacă este dezactivat, intrările aprobate nu mai pot fi modificate sau șterse de către utilizatorul care le-a adăugat. Această setare nu are efect decât dacă este activată opțiunea „Aprobare necesară”.';
$string['mapexistingfield'] = 'Mapat la {$a}';
$string['mapnewfield'] = 'Creează un nou câmp';
$string['mappingwarning'] = 'Toate câmpurile vechi care nu au un câmp nou echivalent se vor pierde şi informaţiile din acele câmpuri vor fi şterse.';
$string['maxentries'] = 'Numărul maxim de intrări';
$string['maxentries_help'] = 'Numărul maxim de intrări care sunt permise unui student pentru  acestă activitate.';
$string['maxsize'] = 'Dimensiune maximă';
$string['menu'] = 'Meniu';
$string['menuchoose'] = 'Alegeţi...';
$string['missingdata'] = 'ID-ul sau obiectul datelor trebuie furnizate clasei de câmp';
$string['missingfield'] = 'Eroare programator: trebuie să specificați câmpul și / sau datele atunci când definiți clasa câmpului.';
$string['modulename'] = 'Bază de date';
$string['modulename_help'] = 'Activitatea de tip bază de date permite participanților să creeze, să întrețină și să caute o colecție de intrări (adică înregistrări). Structura înregistrărilor este definită de profesor ca un număr de câmpuri. Tipurile de câmpuri includ casetă de selectare, butoane radio, meniu derulant, zonă de text, adresă URL, imagine și fișier încărcat.

Aspectul vizual al informațiilor la listarea, vizualizarea sau editarea intrărilor bazei de date poate fi controlat de șabloane de aspect. Activitățile bazei de date pot fi partajate între cursuri ca presetări și un profesor poate importa și exporta intrări în baza de date.

Dacă filtrul de conectare automată a termenilor din baza de date este activat, oricare intrări dintr-o bază de date vor fi conectate automat acolo unde cuvintele sau expresiile apar în cadrul cursului.

Un profesor poate permite comentarii la intrări. Înscrierile pot fi, de asemenea, evaluate de profesori sau cursanți (evaluate de către colegi). Evaluările pot fi agregate pentru a forma o notă finală care este înregistrată în carnetul de note.

Activitățile bazei de date au multe utilizări, cum ar fi

* O colecție colaborativă de link-uri web, cărți, recenzii de cărți, referințe de jurnale etc.
* Pentru afișarea de fotografii, postere, site-uri web sau poezii create de elevi pentru comentarii și recenzii de la colegi.';
$string['modulenameplural'] = 'Baze de date';
$string['more'] = 'Detalii suplimentare';
$string['moreurl'] = 'Detalii suplimentare URL';
$string['movezipfailed'] = 'Arhiva nu poate fi transferată';
$string['multientry'] = 'Articol duplicat';
$string['multimenu'] = 'Meniu (selecţie multiplă)';
$string['multipletags'] = 'Au fost găsite etichete multiple! Şablonul nu a fost salvat';
$string['newentry'] = 'Articol nou';
$string['newfield'] = 'Creează câmp nou';
$string['newfield_help'] = 'Un câmp permite introducerea de date și informații cu diferite formate. Fiecare intrare dintr-o activitate a bazei de date poate avea mai multe câmpuri de mai multe tipuri, cum ar fi un câmp de dată, care permite participanților să selecteze o zi, o lună și un an dintr-un meniu derulant, un câmp de imagine, care permite participanților să încarce un fișier imagine, sau un câmp de casetă de selectare, care permite participanților să selecteze una sau mai multe opțiuni.

Fiecare câmp trebuie să aibă un nume de câmp unic. Descrierea câmpului este opțională.';
$string['noaccess'] = 'Nu aveţi permisiunea să accesaţi această pagină';
$string['nodefinedfields'] = 'Nu aţi definit câmpuri pentru acest nou parametru implicit!';
$string['nofieldcontent'] = 'Nu s-a găsit conținutul fișierului';
$string['nofieldindatabase'] = 'Nu au fost definite câmpuri pentru această nouă bază de date.';
$string['nolisttemplate'] = 'Şablonul de listă încă nu a fost definit';
$string['nomatch'] = 'Nu s-au găsit articole care să corespundă criteriilor selectate!';
$string['nomaximum'] = 'Niciun maxim';
$string['norecords'] = 'Nu s-au găsit articole în baza de date';
$string['nosingletemplate'] = 'Şablul individual nu a fost încă definit';
$string['notapproved'] = 'Acest articol nu a fost încă aprobat.';
$string['notinjectivemap'] = 'Nu este o mapare injectivă';
$string['notopenyet'] = 'Ne pare rău, această activitate nu este disponibilă până în {$a}';
$string['number'] = 'Număr';
$string['numberrssarticles'] = 'Intrări în fluxul RSS';
$string['numnotapproved'] = 'În aşteptare';
$string['numrecords'] = '{$a} articole';
$string['ods'] = '<abbr title="OpenDocument Spreadsheet">ODS</abbr>&nbsp;(OpenOffice)';
$string['openafterclose'] = 'Ați specificat o dată de deschidere după data de închidere';
$string['optionaldescription'] = 'Scurtă descriere (opţional)';
$string['optionalfilename'] = 'Nume fişier (opţional)';
$string['other'] = 'Altele';
$string['overrwritedesc'] = 'Suprascrieți presetarea dacă există deja';
$string['overwrite'] = 'Suprascrie';
$string['overwritesettings'] = 'Suprascrie setări curente';
$string['page-mod-data-x'] = 'Orice pagină a modulului cu activitatea din baza de date';
$string['pagesize'] = 'Articole pe pagină';
$string['participants'] = 'Participanţi';
$string['picture'] = 'Imagine';
$string['pleaseaddsome'] = 'Pentru a începe alegeţi unul din lista de mai jos sau <a href="{$a}">selectaţi un set predefinit</a>.';
$string['pluginadministration'] = 'Administrarea activității bazei de date';
$string['pluginname'] = 'Bază de date';
$string['portfolionotfile'] = 'Exportați într-un portofoliu sau într-un fișier CSV';
$string['presetinfo'] = 'Dacă salvaţi acest parametru ca implicit şablonul va fi publicat. Alţi utilizatori vor putea să-l folosească în propriile baze de date.';
$string['presets'] = 'Parametri impliciţi';
$string['privacy:metadata:commentpurpose'] = 'Comentarii privind înregistrările bazei de date';
$string['privacy:metadata:data_content'] = 'Reprezintă un răspuns la un câmp din modulul de activitate al bazei de date';
$string['privacy:metadata:data_content:content'] = 'Conţinut';
$string['privacy:metadata:data_content:content1'] = 'Conținut suplimentar 1';
$string['privacy:metadata:data_content:content2'] = 'Conținut suplimentar 2';
$string['privacy:metadata:data_content:content3'] = 'Conținut suplimentar 3';
$string['privacy:metadata:data_content:content4'] = 'Conținut suplimentar 4';
$string['privacy:metadata:data_content:fieldid'] = 'ID-ul definiției câmpului';
$string['privacy:metadata:data_records'] = 'Reprezintă înregistrările în modulul de activitate al bazei de date';
$string['privacy:metadata:data_records:approved'] = 'Starea aprobării';
$string['privacy:metadata:data_records:groupid'] = 'Grup';
$string['privacy:metadata:data_records:timecreated'] = 'Ora când a fost creată înregistrarea';
$string['privacy:metadata:data_records:timemodified'] = 'Ora când ultima înregistrare a fost modificată';
$string['privacy:metadata:data_records:userid'] = 'Utilizator care a creat înregistrarea';
$string['privacy:metadata:datafieldnpluginsummary'] = 'Câmpuri pentru activitate de tip bază de date';
$string['privacy:metadata:filepurpose'] = 'Fișier atașat la înregistrarea bazei de date';
$string['privacy:metadata:ratingpurpose'] = 'Evaluări în înregistrările bazei de date';
$string['privacy:metadata:tagpurpose'] = 'Etichete pe înregistrările bazei de date';
$string['radiobutton'] = 'Radio buttons';
$string['recordapproved'] = 'Articol aprobat';
$string['recorddeleted'] = 'Articol şters';
$string['recorddisapproved'] = 'Postare neaprobată';
$string['recordsnotsaved'] = 'Nu s-a salvat niciun articol. Vă rugăm verificaţi formatul fişierului încărcat.';
$string['recordssaved'] = 'articole salvate';
$string['removealldatatags'] = 'Eliminați toate etichetele bazei de date';
$string['requireapproval'] = 'Este necesară aprobarea';
$string['requireapproval_help'] = 'Dacă opțiunea este activată, intrările vor necesita aprobarea unui profesor înainte de a fi vizibile de către toți utilizatorii.';
$string['required'] = 'Necesar';
$string['requiredentries'] = 'Intrări necesare pentru finalizare (vechi)';
$string['requiredentries_help'] = 'Dacă este setat, se afișează un mesaj care indică numărul de intrări necesare pentru finalizare. Rețineți că această setare nu este conectată la finalizarea activității.

Pentru intrările necesare pentru finalizarea activității, ar trebui utilizată noua setare de finalizare a activității „Necesită intrări”. Pentru a elimina complet această setare, setați-o la niciuna, apoi salvați modificările.
Vă rugăm să folosiți câmpurile obligatorii pentru intrări în secțiunea Finalizare activitate.';
$string['requiredentriestoview'] = 'Articole obligatorii înainte de vizualizare';
$string['requiredentriestoview_help'] = 'Numărul de intrări pe care un cursant trebuie să îl predea pentru a putea vizualiza intrările celorlalți cursanți.

Observație: Dacă efectuarea de intrări este o condiiție pentru a permite vizualizarea activității altor participanți atunci filtrul de link-uri automate a bazei de date trebuie dezactivat. Acest lucru se datorează faptului că filtrul de link-uri automate a bazei de date nu poate determina dacă un utilizator a prezentat numărul necesar de intrări.';
$string['requiredentrieswarning'] = 'Această setare a fost înlocuită de o setare de finalizare a activității „Necesită intrări”';
$string['requiredfield'] = 'Câmp necesar';
$string['resetsettings'] = 'Resetează filtre';
$string['resettemplate'] = 'Resetează şablon';
$string['resizingimages'] = 'Se modifică dimensiunile imaginilor reduse';
$string['rows'] = 'rânduri';
$string['rssglobaldisabled'] = 'Dezactivat. Pentru detalii vezi variabilele de configurare ale sitului.';
$string['rsstemplate'] = 'Şablon RSS';
$string['rsstitletemplate'] = 'Şablon titlu RSS';
$string['rsstype'] = 'Flux RSS pentru această activitate';
$string['save'] = 'Salvează';
$string['saveandadd'] = 'Salvează şi adaugă un altul';
$string['saveandview'] = 'Salvează şi vizualizează';
$string['saveaspreset'] = 'Salvează ca implicit';
$string['saveaspreset_help'] = 'Salvarea ca set predefinit va publica template-ul și câmpurile editabile ca un set predefinit de caracteristici pe care ulterior și alți utilizatori ai site-ului vor putea să îl utilizeze.(puteţi şterge setul din lista de presetări în orice moment.)';
$string['savesettings'] = 'Salvează setări';
$string['savesuccess'] = 'Salvat cu succes. Parametrul implicit va fi acum disponibil peste tot în cadrul sitului.';
$string['savetemplate'] = 'Salvează şablon';
$string['search'] = 'Căutare';
$string['search:activity'] = 'Baza de date - informații privind activitatea';
$string['search:entry'] = 'Baza de date- postări';
$string['selectedrequired'] = 'Toate elementele selectate sunt obligatorii';
$string['selectexportoptions'] = 'Selectare opțiuni de export';
$string['selectfields'] = 'Selectare câmpuri';
$string['showall'] = 'Afişează toate articolele';
$string['single'] = 'Afişează unul singur';
$string['singletemplate'] = 'Şablon individual';
$string['subplugintype_datafield'] = 'Tipul câmpului bazei de date';
$string['subplugintype_datafield_plural'] = 'Tipuri de câmpuri de baze de date';
$string['subplugintype_datapreset'] = 'Parametru implicit';
$string['subplugintype_datapreset_plural'] = 'Parametri impliciţi';
$string['tagarea_data_records'] = 'Înregistrări de date';
$string['tags'] = 'Etichete';
$string['tagsdeleted'] = 'Etichetele bazei de date au fost șterse';
$string['teachersandstudents'] = '{$a->teachers} şi {$a->students}';
$string['templates'] = 'Şabloane';
$string['templatesaved'] = 'Şablon salvat';
$string['text'] = 'Text';
$string['textarea'] = 'Textarea';
$string['timeadded'] = 'Ora la care a fost adăugat';
$string['timemodified'] = 'Ora la care a fost modificat';
$string['todatabase'] = 'în această bază de date.';
$string['type'] = 'Tip câmp';
$string['undefinedprocessactionmethod'] = 'În Data_Preset nu a fost definită nicio metodă pentru administrarea acţiunii "{$a}".';
$string['unsupportedexport'] = '({$a->fieldtype}) nu poate fi exportat.';
$string['unsupportedfields'] = 'Câmpuri care nu sunt acceptate';
$string['unsupportedfieldslist'] = 'Următoarele câmpuri nu pot fi exportate:';
$string['updatefield'] = 'Actualizează un câmp existent';
$string['uploadfile'] = 'Încarcă fişier';
$string['uploadrecords'] = 'Încarcă articole dintr-un fişier';
$string['uploadrecords_help'] = 'Intrările pot fi încărcate prin fișier text. Formatul fișierului ar trebui să fie după cum urmează:

* Fiecare linie a fișierului conține o înregistrare
* Fiecare înregistrare este o serie de date separate prin virgule (sau alți delimitatori)
* Prima înregistrare conține o listă de nume de câmp care definesc formatul restului fișierului

Incinta de câmp este un caracter care înconjoară fiecare câmp din fiecare înregistrare. În mod normal, poate fi lăsat nesetat.';
$string['url'] = 'Url';
$string['usedate'] = 'Include în căutare';
$string['usestandard'] = 'Foloseşte un parametru implicit';
$string['usestandard_help'] = 'Pentru a utiliza un set predefinit de caracteristici pentru întreg site-ul, selectaţi-l din listă. (În cazul în care Dvs. sunteți cel ce a adăugat un set predefinit de caracteristici la listă folosind opțiunea de salvare ca set predefinit, atunci aveţi opţiunea de a șterge acest set)';
$string['viewfromdate'] = 'Vizibil din';
$string['viewtodate'] = 'Vizibil pentru';
$string['viewtodatevalidation'] = 'Numai citirea până în prezent nu poate fi înainte de citirea numai din data.';
$string['wrongdataid'] = 'A fost furnizat un id greşit pentru date';
