<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'dmelearn', language 'ro', version '3.9'.
 *
 * @package     dmelearn
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['accessdenied'] = 'Acces interzis';
$string['alwaysopen'] = 'Întotdeauna deschis';
$string['daysavailable'] = 'Zile disponibile';
$string['dmelearn'] = 'DM e-Learning';
$string['dmelearn:addentries'] = 'Adaugă postări Digital Media e-Learning';
$string['dmelearn:addinstance'] = 'Adaugă instanțe Digital Media e-Learning';
$string['dmelearnquestion'] = 'Întrebări Digital Media e-Learning';
$string['dmelearnsetting'] = 'Setări Digital Media e-Learning';
$string['dmelearnsetting_URL'] = 'URL ELMO API';
$string['dmelearnsetting_appname'] = 'Denumirea aplicației ELMO';
$string['dmelearnsetting_appname_help'] = 'Numele aplicației care a fost creată special pentru Moodle';
$string['editingended'] = 'Perioada de editare s-a terminat';
$string['editingends'] = 'Perioada de editare se termină';
$string['elmo'] = 'ELMO';
$string['entries'] = 'Postări';
$string['mailsubject'] = 'Feedback Digital Media e-Learning';
$string['mfselectcourse'] = 'Vă rugăm să selectați un curs...';
$string['modulename'] = 'e-Learning DM';
$string['modulenameplural'] = 'Module de e-Learning DM';
$string['noentriesmanagers'] = 'Nu există profesori';
$string['noentry'] = 'Nu există postări';
$string['pluginadministration'] = 'Administrare DM e-Learning';
$string['saveallfeedback'] = 'Salvează tot feedback-ul meu';
$string['showrecentactivity'] = 'Afișează activitatea recentă';
$string['viewentries'] = 'Vezi postările';
