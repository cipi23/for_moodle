<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'domoscio', language 'ro', version '3.9'.
 *
 * @package     domoscio
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['answer'] = 'Răspuns :';
$string['at'] = ',';
$string['back_btn'] = 'Înapoi';
$string['back_to_coursepage'] = 'Întoarce-te la curs';
$string['choose'] = 'Alege...';
$string['choose_q'] = 'Selectează întrebări';
$string['correction'] = 'Răsounsul corect este :';
$string['create_q'] = 'Creează întrebări';
$string['days'] = 'zile';
$string['delete'] = 'Șterge';
$string['do_training'] = 'Training';
$string['domoscio'] = 'domoscio';
$string['domoscio:addinstance'] = 'Adaugă un nou test';
$string['enrol_students'] = 'Cursanți înscriși';
$string['import_activities'] = 'Importă activități';
$string['modulename'] = 'Domoscio';
$string['next_btn'] = 'Următorul';
$string['next_page'] = 'Pagina următoare';
$string['no_stats'] = 'Nu există în prezent date disponibile';
$string['notion_title'] = 'Titlu :';
$string['num'] = 'N°';
$string['pluginname'] = 'Domoscio pentru Moodle';
$string['prev_page'] = 'Pagina precedentă';
$string['proxy_permission_required'] = 'Nu aveți permisiunea să accesați acest url.';
$string['question'] = 'Întrebare';
$string['results'] = 'Rezultate';
$string['set_notions'] = 'Noțiuni selectate:';
$string['start_tests'] = 'Începe sesiunea';
$string['state'] = 'Status';
$string['stats'] = 'Rezultate';
$string['stats_adv'] = 'Mai mult';
$string['student'] = 'Student';
$string['text2'] = 'test';
$string['today'] = 'Azi';
$string['tomorrow'] = 'Mâine';
$string['warning'] = 'Avertizare';
$string['welcome'] = 'Bine ați venit,';
