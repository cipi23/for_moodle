<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'ejsapp', language 'ro', version '3.9'.
 *
 * @package     ejsapp
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['appletfile'] = 'Simulare Easy Java(script)';
$string['appletfile_required'] = 'Trebuie să selectați un fișier .jar sau un fișier .zip';
$string['check_activity'] = 'Verifică activitatea';
$string['collab_access'] = 'Aceasta este o sesiune de colaborare.';
$string['css_style'] = 'Stylesheet CSS';
$string['default_general_set'] = 'Setări generale';
$string['ejsapp'] = 'EJSApp';
$string['ejsapp:addinstance'] = 'Adăugați o nouă activitate EJSApp';
$string['ejsapp:view'] = 'Vezi o activitate EJSApp';
$string['ejsapp_activity_selection'] = 'Selectarea activității EJSApp';
$string['event_viewed'] = 'Activitatea EJSApp a fost vizualizată';
$string['file_error'] = 'Nu se poate deschide fișierul de pe server';
$string['manifest_error'] = '> Nu se poate găsi sau deschide manifest .mf .Verificați fișierul pe care l-ați uploadat.';
$string['max_value'] = 'Valoare maximă {no}';
$string['max_value_help'] = 'Valoarea maximă permisă a variabilei.';
$string['min_value'] = 'Valoare minimă {no}';
$string['min_value_help'] = 'Valoarea minimă permisă a variabilei.';
$string['modulename'] = 'EJSApp';
$string['modulenameplural'] = 'EJSApps';
$string['no_ejsapps'] = 'Activitatea EJSApp selectată nu are variabile personalizate';
$string['noejsapps'] = 'Nu există activități EJSApp în acest curs';
$string['personalVars_pageTitle'] = 'Valorile variabilelelor personalizate';
$string['personal_vars_button'] = 'Vezi variabilele personalizate';
$string['personalized_values'] = 'valori_personalizate_';
$string['pluginadministration'] = 'Administrare EJSApp';
$string['pluginname'] = 'EJSApp';
$string['refresh'] = 'Dați refresh ferestrei.';
$string['seconds'] = 'secunde rămase.';
$string['use_personalized_vars'] = 'Personalizează variabilele pentru fiecare utilizator?';
$string['users_ejsapp_selection'] = 'Selectați utilizatorii și activitatea EJSApp';
$string['var_name'] = 'Nume {no}';
$string['var_type'] = 'Tip {no}';
$string['variable_name'] = 'Variabilă';
$string['variable_value'] = 'Valoare';
