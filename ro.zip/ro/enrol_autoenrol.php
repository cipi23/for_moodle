<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'enrol_autoenrol', language 'ro', version '3.9'.
 *
 * @package     enrol_autoenrol
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['alwaysenrol'] = 'Înscrie întotdeauna';
$string['alwaysenrol_help'] = 'Dacă setați Da plugin-urile vor înscrie permanent utilizatori, chiar dacă aceștia au deja acces la curs prin altă metodă.';
$string['auto'] = 'Automat';
$string['auto_desc'] = 'Acest grup a fost creat automat de plugin-ul Înscriere automată. Va fi șters în momentul eliminării plugin-ului Înscriere automată din curs.';
$string['autoenrol:config'] = 'Configirarea înscrierii automate';
$string['autoenrol:hideshowinstance'] = 'Utilizatorul poate activa sau dezactiva sesiunile de înscrieri automate';
$string['autoenrol:manage'] = 'Gestionarea utilizatorilor înscriși automat';
$string['autoenrol:method'] = 'Utilizatorul poate înscrie utilizatorii la curs în momentul autentificării';
$string['autoenrol:unenrol'] = 'Utilizatorul poate retrage utilizatorii înscriși automat';
$string['autoenrol:unenrolself'] = 'Utilizatorii se pot înscrie singuri, dacă sunt înscriși în momentul accesului';
$string['autounenrolaction'] = 'Acțiune de retragere automată';
$string['autounenrolaction_help'] = 'Selectați acțiunea care trebuie întreprinsă,atunci când regula de filtrare a utilizatorului nu mai corespunde. Vă rugăm să observați că unele date și setări ale utilizatorului sunt șterse pe durata retragerii de la curs.';
$string['cannotenrol'] = 'Nu puteți face înscrierea la acest curs prin intermediul înscrierii automate.';
$string['config'] = 'Configurare';
$string['confirmbulkdeleteenrolment'] = 'Sunteți sigur că doriți să ștergeți aceste înscrieri ale utilizatorului?';
$string['countlimit'] = 'Limitează';
$string['countlimit_help'] = 'Această sesiune va ține evidența numărului de înscrieri la curs și poate opri înscrierea utilizatorilor, odată ce acestea au atins un anumit nivel. Setarea implicită la 0 înseamnă "Nelimitat".';
$string['customwelcomemessage'] = 'Personalizează mesajul de întâmpinare';
$string['customwelcomemessage_help'] = 'Mesajul de întâmpinare personalizat poate fi adăugat ca text simplu sau în format automat Moodle, incluzănd etichete HTML și multi-lang.

Următorii substituenți pot fi incluși în mesaj:

* Nume curs {$a->coursename}
* Link către pagina de profil a utilizatorului {$a->profileurl}
* E-mailul utilizatorului {$a->email}
* Numele complet al utilizatorului {$a->fullname}';
$string['defaultrole'] = 'Alocarea implicită a rolului';
$string['defaultrole_desc'] = 'Selectați poziția care trebuie alocată utilizatorilor pe parcursul înscrierilor automate';
$string['deleteselectedusers'] = 'Șterge înscrierile selectate ale utilizatorului';
$string['editselectedusers'] = 'Editează înscrierile selectate ale utilizatorului';
$string['emptyfield'] = 'Nu {$a}';
$string['enrolenddate'] = 'Data finalizării';
$string['enrolenddate_help'] = 'Dacă este activată, utilizatorii vor fi înscriși numai până la această dată.';
$string['enrolstartdate'] = 'Data de începere';
$string['enrolstartdate_help'] = 'Dacă este activată, utilizatorii vor fi înscriși începând cu data respectivă.';
$string['filter'] = 'Permite numai';
$string['filter_help'] = 'Când este selectat un focus de grup, puteți utiliza acest câmp pentru a filtra ce tip de utilizator doriți să înscrieți la curs. De exemplu, dacă ați făcut gruparea cu "manual" după autentificare și filtrare, numai utilizatorii care s-au înscris direct pe site-ul dumneavoastră vor fi înscriși.';
$string['filtering'] = 'Filtrare utilizator';
$string['g_auth'] = 'Metoda Auth';
$string['g_dept'] = 'Departament';
$string['g_email'] = 'Adresa de e-mail';
$string['g_inst'] = 'Instituție';
$string['g_lang'] = 'Limbă';
$string['g_none'] = 'Selectați...';
$string['general'] = 'General';
$string['groupon'] = 'Grupat';
$string['groupon_help'] = 'Înscrierea automată poate adăuga automat utilizatorii la un grup, atunci când aceștia sunt înscriși automat în baza unuia dintre aceste câmpuri de utilizator.';
$string['instancename'] = 'Etichetă personalizată';
$string['instancename_help'] = 'Puteți adăuga o etichetă personalizată, pentru a clarifica ce face această metodă de înscriere. Această opțiune este foarte utilă atunci când există mai multe sesiuni de Înscriere automată la un curs.';
$string['m_course'] = 'Accesarea cursului';
$string['m_site'] = 'Autentificare în platformă';
$string['method'] = 'Înscrie când';
$string['method_help'] = 'Utilizatorii avansați pot utiliza această setare, pentru a schimba comportamentul plugin-ului, astfel încât utilizatorii să fie înscriși la curs la conectare, mai degrabă decât la accesarea cursului. Acest lucru este util pentru cursurile care vor trebui să fie vizibile implicit pe lista "cursurile mele" a utilizatorilor.';
$string['pluginname'] = 'Înscriere automată';
$string['pluginname_desc'] = 'Modulul de înscriere automată asigură utilizatorilor autentificați opțiunea de înscriere și accesul automat la curs. Acest lucru este similar asigurării accesului vizitatorilor, cursanții fiind înscriși permanent și, prin urmare, putând să participe la forum și la activitățile din domeniu.';
$string['privacy:metadata:core_group'] = 'Plugin-ul Înscriere automată poate crea noi grupuri și poate utiliza grupurile existente, pentru a adăuga participanți care corespund filtrului Înscriere automată.';
$string['removegroups'] = 'Elimină grupuri';
$string['removegroups_desc'] = 'Atunci când este ștearsă o sesiune de înscriere, ar trebui să încercăm să eliminăm grupurile create de aceasta?';
$string['role'] = 'Rol';
$string['role_help'] = 'Utilizatorii avansați pot utiliza această setare, pentru a modifica nivelul de acces la care utilizatorii sunt înscriși.';
$string['selfunenrol'] = 'Activați auto-retragerea';
$string['selfunenrol_help'] = 'Când este setată la Da, utilizatorii se pot retrage singuri.';
$string['sendcoursewelcomemessage'] = 'Transmite mesaje de întâmpinare la curs';
$string['sendcoursewelcomemessage_help'] = 'Atunci când un utilizator este înscris automat la curs, este posibil să primească un e-mail cu un mesaj de întâmpinare. Dacă este transmis de pe contactul cursului (implicit, formatorul), și poziția este ocupată de mai mulți utilizatori, atunci e-mailul este transmis de la primul utilizator căruia i-a fost alocată poziția.';
$string['softmatch'] = 'Asociere slabă';
$string['softmatch_help'] = 'Atunci când este activată, Înscrierea automată va înregistra un utilizator dacă acesta corespunde parțial valorii „Permite numai”, fără să solicite o potrivire exactă. Asocierile slabe nu sunt sensibile la majuscule și minuscule. Valoarea „Filtrare după” va fi utilizată pentru numele grupului.';
$string['unenrolselfconfirm'] = 'Sunteți sigur că doriți să vă retrageți singur de la curs "{$a}"? Puteți vizita din nou cursul, pentru a vă reînscrie, dar nu veți regăsi informații precum notele și sarcinile alocate.';
$string['unenrolusers'] = 'Utilizatori retrași';
$string['warning'] = 'Atenție!';
$string['warning_message'] = 'Adăugarea acestui plugin la cursul dumneavoastră va permite utilizatorilor Moodle înregistrați să acceseze cursul. Instalați acest plugin numai, dacă doriți să permiteți accesul deschis la cursul dumneavoastră pentru utilizatorii care s-au conectat.';
$string['welcomemessage'] = 'Mesaj de întâmpinare';
$string['welcometocourse'] = 'Bine ați venit la {$a}';
