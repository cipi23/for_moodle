<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'enrol_badgeenrol', language 'ro', version '3.9'.
 *
 * @package     enrol_badgeenrol
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['about'] = 'Despre';
$string['aboutfeedbacktext'] = 'Dacă aveți un feedback sau orice altă idee referitoare la noi caracteristici, nu ezitați să postați pe {$a->aboutlink} sau să îmi trimiteți un e-mail la {$a->aboutmail}.<br /><br />';
$string['abouttext'] = 'Acest plugin a fost dezvoltat de Matthias Schwabe și face parte din setul de plugin-uri asociate ecusoanelor Moodle .<br />Din acest set fac parte si următoarele plugin-uri {$a->badgeenrol}, {$a->badgepool} și {$a->recentbadges}.';
$string['accessgranted'] = 'Ați obținut toate insignele de site necesare, pentru a vă înscrie la acest curs!';
$string['autoenrol'] = 'Înscrieți-vă automat când a fost atribuită insigna.';
$string['badgeenrol:config'] = 'Adăugați și configurați o sesiune de plugin pentru înscrierea ecusoanelor';
$string['badgeenrol:manage'] = 'Gestionarea unei sesiuni de plugin pentru înscrierea ecusoanelor';
$string['badgeenrol:unenrol'] = 'Retrageți participanții, atunci când sunt înscriși de un plugin pentru înscrierea ecusoanelor';
$string['badgeenrol:unenrolself'] = 'Retrageți-vă de la un curs, atunci când sunteți înscris de un plugin pentru înscrierea ecusoanelor';
$string['donationtext'] = 'Dacă vă place acest plugin și doriți să-mi susțineți munca, nu ezitați să utilizați acest buton de donație Paypal:';
$string['enrolinfo'] = 'Aveți nevoie de următoarele ecusoane de site, pentru a vă înscrie la acest curs:';
$string['enrolme'] = 'Înscrie-mă';
$string['issuedateformat'] = 'z.l.a';
$string['issuedatetext'] = 'emis pe';
$string['nobadgesconfigured'] = 'Nu este configurat niciun ecuson de site necesar pentru înscriere. Vă rugăm să contactați un administrator de curs.';
$string['nobadgesfound'] = 'Nu a fost identificat niciun ecuson de site disponibil.';
$string['plugindirectory'] = 'Pagina directorului plugin-ului Moodle';
$string['pluginname'] = 'Înscriere ecuson';
$string['privacy:metadata'] = 'Plugin-ul de înscriere a ecusonului nu memorează datele personale.';
$string['role'] = 'Rol alocat implicit';
$string['selectbadges'] = 'Ecuson de site necesar pentru înscriere';
$string['unenrol'] = 'Utilizator retras';
$string['unenrolselfconfirm'] = 'Sunteți sigur că doriți să vă retrageți de la curs "{$a}"?';
