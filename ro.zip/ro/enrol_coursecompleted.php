<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'enrol_coursecompleted', language 'ro', version '3.9'.
 *
 * @package     enrol_coursecompleted
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['aftercourse'] = 'După finalizarea cursului: {$a}';
$string['cachedef_compcourses'] = 'Înscriere memorie cache de finalizare a cursului';
$string['compcourse'] = 'Curs finalizat';
$string['compcourse_help'] = 'Ce curs trebuie finalizat.';
$string['coursecompleted:config'] = 'Configurează sesiunile de înscriere la finalizarea cursului';
$string['coursecompleted:enrolpast'] = 'Înscrie utilizatorii care au parcurs anterior cursul';
$string['coursecompleted:manage'] = 'Gestionează utilizatorii înscriși';
$string['coursecompleted:unenrol'] = 'Retrage utilizatori de la curs';
$string['coursecompleted:unenrolself'] = 'Retrageți-vă de la curs';
$string['pluginname'] = 'Înscriere la finalizarea cursului';
$string['pluginname_desc'] = 'Plugin-ul de înscriere la finalizarea cursului permite accesul la cursuri în momentul finalizării unui curs.';
$string['privacy:metadata'] = 'Plugin-ul de înscriere finalizată la curs nu stochează date personale.';
$string['processexpirationstask'] = 'Sarcina de expirare a înscrierii la finalizarea cursului';
$string['status'] = 'Activată';
$string['status_desc'] = 'Permite înscrierea implicită după finalizarea cursului.';
$string['status_help'] = 'Această setare determină dacă este activată înscrierea la finalizarea cursului.';
$string['status_link'] = 'înscriea/ finalizarea cursului';
$string['uponcompleting'] = 'La finalizarea cursului {$a}';
$string['usersenrolled'] = '{$a} Utilizatori înscriși';
$string['willbeenrolled'] = 'Veți fi înscris la acest curs după finalizarea cursului {$a}';
