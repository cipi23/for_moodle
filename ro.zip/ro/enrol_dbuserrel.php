<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'enrol_dbuserrel', language 'ro', version '3.9'.
 *
 * @package     enrol_dbuserrel
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['dbencoding'] = 'Codificarea bazei de date';
$string['dbhost'] = 'Numele sau numărul IP al serverului';
$string['dbhost_desc'] = 'Tastați adresa IP a serverului bazei de date sau numele gazdei';
$string['dbname'] = 'Numele bazei de date';
$string['dbpass'] = 'Parolă server';
$string['dbtable'] = 'Tabelul bazei de date';
$string['dbtype'] = 'Tipul bazei de date';
$string['dbtype_desc'] = 'Numele driver-ului ADOdb al bazei de date, tipul motorului bazei de date externe.';
$string['dbuser'] = 'Utilizator server';
$string['description'] = 'Puteți utiliza o bază de date externă (de aproape orice fel), pentru a  controla relațiile dintre utilizatori. Se presupune că baza de date externă conține un câmp care are două ID-uri de utilizator și un ID de rol. Acestea sunt comparate cu câmpurile pe care le alegeți în tabelele de utilizator și rolurile locale';
$string['enrolname'] = 'Bază de date externă (relații utilizatori)';
$string['localobjectuserfield'] = 'Câmp obiect local';
$string['localobjectuserfield_desc'] = 'Numele câmpului din tabelul utilizatorului pe care îl folosim, pentru a corespunde intrărilor din baza de date la distanță (de exemplu, numărul de ID). pentru <i>object</i> alocarea poziției';
$string['localrolefield'] = 'Câmp rol local';
$string['localrolefield_desc'] = 'Numele câmpului din tabelul de roluri pe care îl folosim, pentru a corespunde intrărilor din baza de date la distanță (de exemplu, denumirea prescurtată).';
$string['localsubjectuserfield'] = 'Câmp subiect local';
$string['localsubjectuserfield_desc'] = 'Numele câmpului din tabelul utilizatorului pe care îl folosim, pentru a corespunde intrărilor din baza de date la distanță (de exemplu, numărul ID). pentru <i>subject</i> alocarea poziției';
$string['pluginname'] = 'Alocarea poziției utilizatorului DB';
$string['pluginname_desc'] = 'Puteți utiliza o bază de date externă (de aproape orice fel), pentru a controla rolul de mentor. Se presupune că baza de date externă conține cel puțin un câmp care are un nume de utilizator cursant, o poziție de mentor și un câmp care conține un nume de utilizator mentor. Acestea sunt comparate cu câmpurile, pe care le alegeți în rolurile locale și tabelele utilizatorului.';
$string['remote_fields_mapping'] = 'Cartografierea câmpului bazei de date';
$string['remoteenroltable'] = 'Tabel înscriere utilizator la distanță';
$string['remoteenroltable_desc'] = 'Specificați numele tabelului care conține lista înscrierilor utilizatorilor. Dacă nu este completat, înseamnă că înscrierea utilizatorului nu se sincronizează.';
$string['remoteobjectuserfield'] = 'Câmp obiect la distanță';
$string['remoteobjectuserfield_desc'] = 'Numele câmpului din tabelul la distanță pe care îl folosim, pentru a corespunde intrărilor din tabelul utilizatorului pentru <i>object</i> alocarea poziției';
$string['remoterolefield'] = 'Câmp poziție la distanță';
$string['remoterolefield_desc'] = 'Numele câmpului din tabelul la distanță pe care îl folosim pentru a corespunde intrărilor din tabelul de roluri.';
$string['remotesubjectuserfield'] = 'Câmp subiect la distanță';
$string['remotesubjectuserfield_desc'] = 'Numele câmpului din tabelul la distanță pe care îl folosim, pentru a corespunde intrărilor din tabelul de roluri pentru <i>subiectul</i> alocării rolului';
$string['server_settings'] = 'Setările serverului bazei de date externe';
$string['settingsheaderdb'] = 'Conectarea la baza de date externă';
