<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'enrol_dps', language 'ro', version '3.9'.
 *
 * @package     enrol_dps
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['assignrole'] = 'Alocă rol';
$string['cost'] = 'Cost';
$string['coursenotfound'] = 'Cursul nu a fost găsit';
$string['currency'] = 'Monedă';
$string['defaultrole'] = 'Alocarea implicită a rolului';
$string['defaultrole_desc'] = 'Selectați rolul care ar trebui să fie atribuit utilizatorilor în timpul înscrierilor DPS';
$string['dps:config'] = 'Configurați sesiunile de înscriere DPS';
$string['dps:manage'] = 'Gestionează utilizatorii înscriși';
$string['dps:unenrol'] = 'Retrage utilizatorii de la curs';
$string['dps:unenrolself'] = 'Retrageți-vă de la curs';
$string['enrolenddate'] = 'Data de finalizare';
$string['enrolenddate_help'] = 'Dacă este activată, utilizatorii se pot înscrie numai până la acea dată.';
$string['enrolperiod'] = 'Durata înscrierii';
$string['enrolperiod_desc'] = 'Intervalul implicit de timp în care înscrierea este validă (în secunde). Dacă este setat la zero, intervalul înscrierii va fi implicit nelimitat.';
$string['enrolperiod_help'] = 'Intervalul implicit de timp în care înscrierea este validă, începând cu momentul în care utilizatorul este înscris. Dacă este dezactivat, intervalul înscrierii va fi implicit nelimitat .';
$string['enrolstartdate'] = 'Data începerii';
$string['enrolstartdate_help'] = 'Dacă este activată, utilizatorii pot fi înscriși numai începând cu această dată.';
$string['error_curlrequired'] = 'Extensia PHP Curl este necesară pentru plugin-ul de înscriere DPS.';
$string['error_dpscurrency'] = 'Taxa de curs nu este într-o monedă recunoscută de DPS.';
$string['error_dpsinitiate'] = 'tranzacția cu serverul de plăți DPS nu a putut fi inițiată  - vă rugăm să încercați din nou mai târziu.';
$string['error_enrolmentkey'] = 'Cheia de înscriere a fost incorectă, vă rugăm să încercați din nou.';
$string['error_paymentfailure'] = 'Plata dvs. nu a reușit. DPS Payment Express a transmis notificare privind următoarea eroare: $a';
$string['error_paymentunsucessful'] = 'Plata nu a reușit. Vă rugăm să încercați din nou mai târziu.';
$string['error_txalreadyprocessed'] = 'DPS Payment Express: Această tranzacție a fost deja procesată.';
$string['error_txdatabase'] = 'Inevitabil: nu a putut fi creată tranzacția DPS în baza de date Moodle.';
$string['error_txinvalid'] = 'DPS Payment Express: tranzacție invalidă, vă rugăm să încercați din nou.';
$string['error_txnotfound'] = 'DPS Payment Express: înregistrarea tranzacției Moodle corespunzătoare nu a fost găsită.';
$string['error_usercourseempty'] = 'utilizator sau curs gol';
$string['key'] = 'Cheie DPS';
$string['key_desc'] = 'Aceasta este cheia privată DPS, care a fost emisă cu ID-ul utilizatorului.';
$string['nocost'] = 'Înscrierea la acest curs nu implică niciun cost!';
$string['pluginname'] = 'Gateway de plată DPS';
$string['pluginname_desc'] = 'Acest plugin permite configurarea cursurilor, pentru a fi plătite prin intermediul gateway-ului de plată cu cardul de credit DPS.';
$string['status'] = 'Permiteți înscrieri DPS';
$string['status_desc'] = 'Permiteți utilizatorilor să folosească DPS, pentru a se înscrie implicit la curs.';
$string['unavailabletoguest'] = 'Acest curs nu este gratuit și nu este disponibil pentru utilizatorul vizitator.';
$string['userid'] = 'ID utilizator DPS';
$string['userid_desc'] = 'ID-ul utilizatorului DPS User ID pentru autorizarea cardului de credit.';
