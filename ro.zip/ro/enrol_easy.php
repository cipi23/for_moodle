<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'enrol_easy', language 'ro', version '3.9'.
 *
 * @package     enrol_easy
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['easy:config'] = 'Configurați sesiunile Înscriere facilă';
$string['easy:delete'] = 'Ștergeți sesiunile Înscriere facilă';
$string['easy:manage'] = 'Gestionați sesiunile Înscriere facilă';
$string['easy:unenrol'] = 'Retrage din sesiunile Înscriere facilă';
$string['easy:unenrolself'] = 'Retrage din curs';
$string['enrolenddate'] = 'Înscrierea se încheie';
$string['enrolenddate_help'] = 'Cursanții nu se vor putea înscrie după această dată.';
$string['enrolform_course_code'] = 'Cod de înscriere';
$string['enrolform_heading'] = 'Înscrie într-un curs';
$string['enrolform_pagetitle'] = 'Înscrie într-un curs';
$string['enrolform_submit'] = 'Înscrie';
$string['enrolstartdate'] = 'Înscrierea a început';
$string['enrolstartdate_help'] = 'Cursanții nu se vor putea înscrie înainte de această dată.';
$string['error_disabled_global'] = 'Înscrierea facilă este dezactivată pentru acest curs.';
$string['error_enrolenddate'] = 'Înscrierile pentru acest curs au luat sfârșit.';
$string['error_enrolstartdate'] = 'Înscrierile pentru acest curs nu au început încă.';
$string['error_invalid_code'] = 'Cod de înscriere invalid.';
$string['header_coursecodes'] = 'Coduri de înscriere';
$string['pluginname'] = 'Înscrieri facile';
$string['pluginname_desc'] = 'Permite înscrierea facilă prin intermediul unui cod text.';
$string['qrenabled'] = 'Activează înscrierea prin intermediul codurilor QR';
$string['qrenableddesc'] = 'Activează înscrierea prin intermediul codurilor QR';
$string['regenerate_codes'] = 'Regenerează coduri';
$string['regenerate_codes_help'] = 'Bifați aici și dați click pe "Salvează modificările", pentru a genera din nou codurile de înscriere de mai sus.';
$string['showqronmobile'] = 'Activați cititorul de cod QR pe telefonul mobil';
$string['showqronmobiledesc'] = 'Activați Înscrierea prin coduri QR pe dispozitivele mobile. Este posibil să nu funcționeze pe toate browser-ele mobile. Utilizarea preferată a codurilor QR se face în browser-ul Chrome și pe un desktop, laptop sau Chromebook.';
$string['status'] = 'Activat';
$string['status_help'] = 'Setați „Da”, pentru a activa înscrierea. Setați „Nu”, pentru a dezactiva înscrierea.';
$string['unenrolselfconfirm'] = 'Sunteți sigur că doriți să vă retrageți de la curs? "{$a}"?';
