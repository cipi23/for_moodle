<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'enrol_elightenment', language 'ro', version '3.9'.
 *
 * @package     enrol_elightenment
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['assignrole'] = 'Alocă rol';
$string['businessemail'] = 'E-mail Paypal';
$string['businessemail_desc'] = '';
$string['cOutBttn'] = 'Deconectare';
$string['cartTitle'] = 'Coș curs';
$string['catSearch'] = 'Caută după categorie';
$string['cost'] = 'Cost înscriere';
$string['costerror'] = 'Costul înscrierii nu este numeric';
$string['costorkey'] = 'Vă rugăm să selectați una dintre următoarele metode de înscriere.';
$string['currency'] = 'Cod monedă';
$string['defaultrole'] = 'Alocarea implicită a poziției';
$string['defaultrole_desc'] = 'Selectați rolul care ar trebui să fie atribuit utilizatorilor în timpul înscrierilor';
$string['elightenment:config'] = 'Configurează sesiunile de înscriere';
$string['elightenment:manage'] = 'Gestionează utilizatorii înscriși';
$string['elightenment:unenrol'] = 'Retrage utilizatorii de la curs';
$string['elightenment:unenrolself'] = 'Retrageți-vă de la curs';
$string['emptyCart'] = 'Goșul dumneavoastră este gol';
$string['enrolenddate'] = 'Data de finalizare';
$string['enrolenddate_help'] = 'Dacă este activată, utilizatorii se pot înscrie numai până la această dată.';
$string['enrolenddaterror'] = 'Data de finalizare a înscrierii nu poate fi anterioară datei de începere';
$string['enrolperiod'] = 'Durata înscrierii/ abonării';
$string['enrolperiod_desc'] = 'Intervalul implicit de timp în care înscrierea este validă. Acesta trebuie setat, dacă cursul este un abonament!';
$string['enrolperiod_help'] = 'Intervalul implicit de timp în care înscrierea este validă, începând cu momentul în care utilizatorul este înscris. Dacă este dezactivat, intervalul înscrierii va fi implicit nelimitată.';
$string['enrolstartdate'] = 'Data începerii';
$string['enrolstartdate_help'] = 'Dacă este activată, utilizatorii pot fi înscriși numai începând cu această dată.';
$string['expiredaction'] = 'Acțiunea de expirare a înscrierii';
$string['expiredaction_help'] = 'Selectați acțiunea care trebuie întreprinsă la expirarea înscrierii utilizatorului. Vă rugăm să rețineți că unele date și setări ale utilizatorilor sunt eliminate din curs în timpul retragerii de la curs.';
$string['mailadmins'] = 'Notifică administratorul';
$string['mailstudents'] = 'Notifică studenții';
$string['mailteachers'] = 'Notifică formatorii';
$string['nameSearch'] = 'Caută după numele cursului';
$string['nocost'] = 'Acest curs este gratuit!';
$string['pluginname'] = 'Clarificare';
$string['pluginname_desc'] = 'clarificare sistem de formare plătit';
$string['purchase'] = 'Achiziționează';
$string['removeCourse'] = 'Elimină';
$string['search'] = 'Caută';
$string['sendpaymentbutton'] = 'Adăugă în coș';
$string['shopTitle'] = 'Catalog curs';
$string['status'] = 'Permite înscrierile plătite';
$string['status_desc'] = 'Permiteți utilizatorilor să folosească clarificarea pentru a se înscrie implicit la un curs.';
$string['subscribe'] = 'Abonare';
$string['subscribe_desc'] = 'Verificați dacă aceasta este un abonament';
$string['unenrolselfconfirm'] = 'Doriți să vă retrageți de la curs "{$a}"?';
