<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'enrol_extendedguest', language 'ro', version '3.9'.
 *
 * @package     enrol_extendedguest
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['authenticated_users'] = 'Permiteți accesul utilizatorilor vizitatori autentificați ?';
$string['extendedguest:config'] = 'Configurați sesiunile de acces extins pentru vizitatori';
$string['guestaccess_withoutpassword'] = 'Acces extins pentru vizitatori';
$string['localnet'] = 'Permiteți accesul vizitatorilor la utilizatorii locali?';
$string['pluginname'] = 'Acces extins pentru vizitatori';
$string['pluginname_desc'] = 'Acest plugin permite accesul vizitatorilor la anumite IP-uri, rețele sau utilizatori autentificați.';
$string['privacy:metadata'] = 'Plugin-ul de acces extins pentru vizitatori nu memorează datele personale.';
$string['settings_list_ip'] = 'Permite lista IP';
$string['settings_list_ip_helptext'] = 'Puneți fiecare intrare pe o singură linie. Intrările valide sunt, fie adresa IP completă (cum ar fi <b>192.168.10.1</b>) care se potrivește cu o singură gazdă; fie adresa parțială (cum ar fi <b>192.168</b>) care se potrivește cu orice adresă începând cu acele numere; fie notația CIDR (cum ar fi <b>231.54.211.0/20</b>); fie o serie de adrese IP (cum ar fi <b>231.3.56.10-20</b>) unde intervalul se aplică ultimei părți a adresei. Numele de domeniu text (cum ar fi \'example.com\') nu sunt acceptate. Liniile goale sunt ignorate.';
$string['status'] = 'Activați accesul extins pentru vizitatori';
$string['status_desc'] = 'Dacă îl activați, accesul extins pentru vizitatori va fi activat automat.';
