<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'enrol_grabber', language 'ro', version '3.9'.
 *
 * @package     enrol_grabber
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['alreadygrabbedinstance'] = 'Această instanță de înscriere este deja captată de o metodă de înscriere din acest curs.';
$string['assignrole'] = 'Alocă poziția';
$string['browsecohorts'] = 'Răsfoiește cohortele';
$string['browseusers'] = 'Răsfoiește utilizatorii';
$string['cantusewithoutinstances'] = 'Nu se poate folosi această metodă de înscriere fără alte sesiuni de înscriere pentru acest curs';
$string['confirmbulkdeleteenrolment'] = 'Sunteți sigur că doriți să ștergeți înscrierile acestor utilizatori?';
$string['defaultstart'] = 'Începerea implicită a înscrierii';
$string['deleteback'] = 'În timp ce ștergeți această sesiune, restaurați toate înregistrările sale la metoda de înscriere asociată';
$string['deleteback_desc'] = 'În timp ce ștergeți această sesiune, restaurați toate înregistrările sale la metoda de înscriere asociată';
$string['deleteselectedusers'] = 'Ștergeți înregistrările utilizatorilor selectați';
$string['editselectedusers'] = 'Editați înscrierile utilizatorilor selectați';
$string['enrolledincourserole'] = 'Înscris la "{$a->course}" ca "{$a->role}"';
$string['enrolusers'] = 'Înscrie utilizatorii la sesiunea de captură';
$string['grabber:config'] = 'Configurează sesiunile de captură a înscrierilor';
$string['grabber:delete'] = 'Șterge sesiunea de captură';
$string['grabber:enrol'] = 'Înscrie utilizatorii';
$string['grabber:manage'] = 'Gestionează înscrierile utilizatorilor';
$string['grabber:unenrol'] = 'Retrageți utilizatorii de la curs';
$string['grabber:unenrolself'] = 'Retrageți-vă de la curs';
$string['grabberenrolinstance'] = 'înscriere sesiune de captură (același curs)';
$string['pluginname'] = 'Captură înscrieri';
$string['pluginname_desc'] = 'Plugin-ul de captură a înscrierilor permite recuperarea acestora dintr-o altă sesiune de înscriere la același curs. De asemenea, permite ca o înscriere să fie continuată manual printr-o înscriere/ anulare.';
$string['status'] = 'Activați captura înscrierilor';
$string['status_desc'] = 'Permiteți accesul la cursuri al utilizatorilor înscriși intern. Acesta ar trebui activat în majoritatea cazurilor.';
$string['status_help'] = 'Această setare determină dacă utilizatorii pot fi înscriși manual, printr-un link în setările de administrare a cursului, de către un utilizator cu permisiuni adecvate, cum ar fi un formator.';
$string['statusdisabled'] = 'Deazactivare';
$string['statusenabled'] = 'Activată';
$string['unenrol'] = 'Retrage utilizatori';
$string['unenrolselectedusers'] = 'Retrage utilizatorii selectați';
$string['unenroluser'] = 'Sunteți sigur că doriți să-l retrageți "{$a->user}" de la cursul "{$a->course}"?';
$string['unenrolusers'] = 'Retrage utilizatori';
