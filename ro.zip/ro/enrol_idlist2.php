<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'enrol_idlist2', language 'ro', version '3.9'.
 *
 * @package     enrol_idlist2
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['enrol_idlist2_authlist'] = 'Lista valorilor autorizate';
$string['enrol_idlist2_authlist_help'] = 'Aceasta este lista valorilor autorizate.
Se obține prin extragerea datelor din câmpul anterior și prin aplicarea expresiei regulate.';
$string['enrol_idlist2_authorized'] = 'Utilizatori autorizați';
$string['enrol_idlist2_authorized_help'] = 'Acesta este numele actualei sesiuni a plugin-ului de înscriere';
$string['enrol_idlist2_campo'] = 'Câmp';
$string['enrol_idlist2_campo_help'] = 'Acesta este numele câmpului utilizat pentru validarea utilizatorului';
$string['enrol_idlist2_idattr'] = 'Atributul studentului utilizat ca ID';
$string['enrol_idlist2_listadeid'] = 'Utilizatori autorizați';
$string['enrol_idlist2_listadeid_help'] = 'Lipiți aici lista valorilor, pe care doriți să le comparați.

Exemplu: Copiați/ Lipiți lista utilizatorilor cărora li se permite accesul la acest curs (id, nume, ...)';
$string['enrol_idlist2_regexp'] = 'Expresie uzuală';
$string['enrol_idlist2_regexp_help'] = 'Expresie uzuală utilizată pentru validarea utilizatorului.

Implicit la [0-9][0-9][0-9][0-9]+';
$string['enrol_idlist2_settinghead'] = 'Plugin de înscriere IDList2';
$string['enrol_idlist2_settinginfo'] = 'Acest plugin nu necesită configurare globală';
$string['enrol_idlist2_unauthorized'] = 'Lista utilizatorilor neautorizați';
$string['enrol_idlist2_unauthorized_help'] = 'Aceasta este lista utilizatorilor neautorizați';
$string['enrol_idlist2_userpicture'] = 'Imagine';
$string['enrol_idlist2_userregexp'] = 'Filtrează câmpul utilizatorului';
$string['enrol_idlist2_userregexp_help'] = 'Filtrează câmpul utilizatorului cu ajutorul expresiei uzuale';
$string['enrolment_id_error'] = 'Se pare că nu sunteți un membru valid al acestui curs. Vă rugăm să vă contactați formatorul, dacă sunteți un participant legitim la acest curs.';
$string['pluginname'] = 'IDList2';
$string['pluginname_desc'] = 'Cu această metodă de înscriere, cursanții sunt înscriși dintr-o listă de ID-uri.';
