<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'enrol_invitation', language 'ro', version '3.9'.
 *
 * @package     enrol_invitation
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['assignrole'] = 'Alocă rol';
$string['cannotsendmoreinvitationfortoday'] = 'Nu au mai rămas invitații pentru astăzi. Încercați mai târziu.';
$string['defaultrole'] = 'Alocarea implicită a rolului';
$string['defaultrole_desc'] = 'Selectați rolul care trebuie atribuit utilizatorilor în timpul înregistrării invitației';
$string['editenrolment'] = 'Editează înscrierea';
$string['emailaddressnumber'] = 'Adresă de e-mail {$a}';
$string['emailmessageinvitation'] = '{$a->managername} v-a invitat să vă alăturați {$a->fullname}.

Pentru a vă alătura, dați click pe următorul link: {$a->enrolurl}

Trebuie să creați un cont, dacă nu aveți unul deja.

{$a->sitename}
-----------------------------
{$a->siteurl}';
$string['emailmessageuserenrolled'] = '{$a->userfullname} s-a înscris la {$a->coursefullname}.

Dați click pe următorul link, pentru a verifica înscrierile noi: {$a->courseenrolledusersurl}

{$a->sitename}
-------------
{$a->siteurl}';
$string['emailssent'] = 'E-mail-ul(e-mail-urile) a(au) fost transmis(e).';
$string['emailtitleinvitation'] = 'Ați fost invitat să v[ alăturați {$a->fullname}.';
$string['emailtitleuserenrolled'] = '{$a->userfullname} s-a înscris în {$a->coursefullname}.';
$string['enrolenddate'] = 'Data de finalizare';
$string['enrolenddate_help'] = 'Dacă este activată, utilizatorii se pot înscrie numai până la această dată.';
$string['enrolenddaterror'] = 'Data de finalizare a înscrierii nu poate fi anterioară datei de începere';
$string['enrolperiod'] = 'Durata înscrierii';
$string['enrolperiod_desc'] = 'Durata de validitate implicită a înscrierii (în secunde). Dacă este setată la zero, durata de validitate a înscrierii va fi nelimitată în mod implicit.';
$string['enrolperiod_help'] = 'Intervalul implicit de timp în care înscrierea este validă, începând cu momentul în care utilizatorul este înscris. Dacă este dezactivat, intervalul înscrierii va fi implicit nelimitat.';
$string['enrolstartdate'] = 'Data începerii';
$string['enrolstartdate_help'] = 'Dacă este activată, utilizatorii pot fi înscriși numai începând cu această dată.';
$string['expiredtoken'] = 'Token invalid - procesul de înscriere s-a oprit.';
$string['invitationpagehelp'] = '<ul><li>V-a(u) mai rămas {$a} invitație(i) pentru azi.</li><li>Fiecare invitație este unică și expiră odată ce este utilizată.</li></ul>';
$string['inviteusers'] = 'Invită utilizatori';
$string['maxinviteerror'] = 'Trebuie să fie un număr.';
$string['maxinviteperday'] = 'Numărul maxim de invitații pe zi';
$string['maxinviteperday_help'] = 'Numărul maxim de invitații care pot fi trimise pe zi pentru acest curs.';
$string['noinvitationinstanceset'] = 'Nu a fost identificată nicio sesiune de invitații de înscriere. Vă rugăm să adăugați mai întâi o sesiune de invitații de înscriere la cursul dvs..';
$string['nopermissiontosendinvitation'] = 'Nu aveți permisiunea de a trimite invitații';
$string['pluginname'] = 'Invitație';
$string['pluginname_desc'] = 'Modulul Invitație permite transmiterea invitațiilor prin e-mail. Aceste invitații pot fi utilizate o singură dată. Utilizatorii care dau click pe linkul de e-mail sunt înscriși automat.';
$string['status'] = 'Autorizați invitația de înscriere';
$string['status_desc'] = 'Permiteți utilizatorilor să invite în mod implicit persoane să se înscrie la un curs.';
$string['unenrol'] = 'Retrage utilizatori';
$string['unenrolselfconfirm'] = 'Sunteți sigur că doriți să vă retrageți de la curs "{$a}"?';
$string['unenroluser'] = 'Sunteți sigur că doriți să-l retrageți pe "{$a->user}" de la cursul "{$a->course}"?';
