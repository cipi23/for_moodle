<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'enrol_ldapuserrel', language 'ro', version '3.9'.
 *
 * @package     enrol_ldapuserrel
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['bind_dn'] = 'Specificați aici utilizatorul consolidat pe care doriți să-l folosiți pentru a căuta utilizatori, . Ceva asemănător cu \'cn=ldapuser,ou=public,o=org\\';
$string['bind_dn_key'] = 'Numele distinct al utilizatorului consolidat';
$string['bind_pw'] = 'Parola pentru utilizatorul consolidat';
$string['bind_pw_key'] = 'Parolă';
$string['bind_settings'] = 'Setări consolidare';
$string['filter'] = 'Filtrul LDAP utilizat pentru a căuta mentori. De regulă, \'(objectclass=*)\' sau \'(objectclass=posixGroup)\\';
$string['filter_key'] = 'Filtrul LDAP';
$string['host_url'] = 'Specificați gazda LDAP sub forma adresei \'ldap://ldap.myorg.com/\' sau \'ldaps://ldap.myorg.com/\\';
$string['host_url_key'] = 'Gazdă URL';
$string['idnumber_attribute'] = 'Numele câmpului din LDAP care reprezintă identificatorul unic al mentorului.';
$string['idnumber_attribute_key'] = 'Identificatorul unic al mentorului din LDAP';
$string['ldap_encoding'] = 'Specificați codificarea utilizată de serverul LDAP. Cel mai probabil utf-8, MS AD v2 folosește codificarea implicită a platformei, cum ar fi cp1252, cp1250 etc.';
$string['ldap_encoding_key'] = 'Codificare LDAP';
$string['localobjectuserfield'] = 'Câmpul utilizatorului în Moodle pentru mentorat';
$string['localobjectuserfield_desc'] = 'Numele câmpului din tabelul utilizatorului Moodle folosit pentru a identifica mentoratul';
$string['localsubjectuserfield'] = 'Câmpul utilizatorului din Moodle pentru mentor';
$string['localsubjectuserfield_desc'] = 'Numele câmpului din tabelul utilizatorului Moodle care este utilizat pentru a identifica mentorul';
$string['pluginname'] = 'Alocarea rolului utilizatorului LDAP';
$string['pluginname_desc'] = 'Puteți utiliza LDAP pentru a vă controla poziția de mentor. Se presupune că LDAP dumneavoastră conține cel puțin un câmp care conține un nume de utilizator mentorat în intrarea mentorului. Acestea sunt comparate cu câmpurile pe care le alegeți în tabelele utilizatorilor locali.';
$string['remote_fields_mapping'] = 'Cartografierea câmpului la distanță LDAP';
$string['role_mapping'] = '<p>Pentru fiecare poziție pe care doriți să o atribuiți din LDAP, trebuie să specificați lista contextelor în care se află mentorii. Separați diferite contexte cu \';\'.</p><p>De asemenea, trebuie să specificați atributul pe care îl folosește serverul LDAP pentru a deține lista persoanelor menționate.</p>';
$string['role_mapping_key'] = 'Mapare roluri din LDAP';
$string['roles'] = 'Cartografierea rolului';
$string['search_sub'] = 'Căutați poziția utilizatorului din subcontexte';
$string['search_sub_key'] = 'Caută subcontexte';
$string['server_settings'] = 'Setările serverului LDAP';
$string['user_type'] = 'Dacă apartenența la grup conține nume distincte, specificați modul în care utilizatorii sunt stocați în LDAP';
$string['user_type_key'] = 'Tip utilizator';
$string['version'] = 'Versiunea protocolului LDAP pe care îl folosește serverul dvs.';
$string['version_key'] = 'Versiune';
