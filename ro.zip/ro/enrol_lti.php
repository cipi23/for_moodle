<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'enrol_lti', language 'ro', version '3.9'.
 *
 * @package     enrol_lti
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['allowframeembedding'] = 'Notă: Se recomandă ca setarea de administrare a site-ului „Permite încorporarea cadrelor” să fie activată, astfel încât instrumentele să fie afișate într-un cadru, mai degrabă decât într-o fereastră nouă.';
$string['authltimustbeenabled'] = 'Notă: Acest plugin necesită și plugin-ul de autentificare LTI.';
$string['cartridgeurl'] = 'URL cartuș';
$string['couldnotestablishproxy'] = 'Nu s-a putut stabili un proxy cu consumatorul.';
$string['enrolenddate'] = 'Data de încheiere';
$string['enrolenddate_help'] = 'Dacă este activat, utilizatorii au acces numai până la această dată.';
$string['enrolenddateerror'] = 'Data de încheiere a înscrierii nu poate fi anterioară datei de începere';
$string['enrolisdisabled'] = 'Plugin-ul „Publicați ca instrument LTI” este dezactivat.';
$string['enrolmentfinished'] = 'Înscrierea s-a încheiat.';
$string['enrolmentnotstarted'] = 'Înscrierea nu a început.';
$string['enrolperiod'] = 'Durata înscrierii';
$string['enrolperiod_help'] = 'Durata de valabilitate a înscrierii, începând cu momentul în care utilizatorul se înscrie de la distanță. Dacă este dezactivat, durata înscrierii va fi nelimitată.';
$string['enrolstartdate'] = 'Data de început';
$string['enrolstartdate_help'] = 'Dacă este activat, utilizatorii au acces numai începând cu această dată.';
$string['failedrequest'] = 'Cerere nereușită. Motiv: {$a->reason}';
$string['frameembeddingnotenabled'] = 'Pentru a accesa instrumentul, vă rugăm să urmați link-ul de mai jos.';
$string['gradesync'] = 'Sincronizarea notelor';
$string['gradesync_help'] = 'Dacă notele din instrument sunt trimise la sistemul la distanță (consumator LTI).';
$string['incorrecttoken'] = 'Token-ul a fost incorect. Verificați adresa URL și încercați din nou sau contactați administratorul acestui instrument.';
$string['invalidrequest'] = 'Cerere invalidă';
$string['invalidtoolconsumer'] = 'Consumator de instrumente invalide.';
$string['launchdetails'] = 'Detalii lansare';
$string['launchdetails_help'] = 'Pentru configurarea instrumentului sunt necesare o adresă URL a cartușului (numită și URL de configurare) plus secret sau o adresă URL de lansare.';
$string['launchurl'] = 'Lansați adresa URL';
$string['lti:config'] = 'Configurați instanțele „Publicați ca instrument LTI”';
$string['lti:unenrol'] = 'Anulați înscrierea utilizatorilor la curs';
$string['maxenrolled'] = 'Număr maxim de utilizatori înscriși';
$string['maxenrolled_help'] = 'Numărul maxim de utilizatori la distanță care pot accesa instrumentul. Dacă este setat la zero, numărul de utilizatori înscriși este nelimitat.';
$string['maxenrolledreached'] = 'A fost atins numărul maxim de utilizatori la distanță autorizați să acceseze instrumentul.';
$string['membersync'] = 'Sincronizarea utilizatorilor';
$string['membersync_help'] = 'Dacă o sarcină planificată sincronizează utilizatorii înscriși în sistemul la distanță cu înscrierile la acest curs, creând un cont pentru fiecare utilizator la distanță, după cum este necesar, și înscriindu-i sau dezinscriindu-i, după cum este necesar.

Dacă este setat la nu, în momentul în care un utilizator la distanță accesează instrumentul, va fi creat un cont pentru acesta și va fi înscris automat.';
$string['membersyncmode'] = 'Mod sincronizare utilizator';
$string['membersyncmode_help'] = 'Dacă utilizatorii la distanță trebuie să fie înscriși și/sau îndepărtați de pe lista celor înscriși la acest curs.';
$string['membersyncmodeenrolandunenrol'] = 'Înscrieți utilizatori noi și anulați lipsa utilizatorilor';
$string['membersyncmodeenrolnew'] = 'Înscrieți utilizatori noi';
$string['membersyncmodeunenrolmissing'] = 'Anulați înregistrarea utilizatorilor lipsă';
$string['notoolsprovided'] = 'Nu sunt furnizate instrumente';
$string['opentool'] = 'Deschideți instrumentul';
$string['pluginname'] = 'Publicați ca instrument LTI';
$string['pluginname_desc'] = 'Plugin-ul „Publicați ca instrument LTI”, împreună cu plugin-ul de autentificare LTI, permite utilizatorilor la distanță să acceseze cursurile și activitățile selectate. Cu alte cuvinte, Moodle funcționează ca un furnizor de instrumente LTI.';
$string['privacy:metadata:enrol_lti_users'] = 'Lista utilizatorilor înscriși prin intermediul unui furnizor LTI';
$string['privacy:metadata:enrol_lti_users:lastaccess'] = 'Ora la care ultimul utilizator a accesat cursul';
$string['privacy:metadata:enrol_lti_users:lastgrade'] = 'Ultima notă pe care a înregistrat-o utilizatorul';
$string['privacy:metadata:enrol_lti_users:timecreated'] = 'Ora la care utilizatorul a fost înscris';
$string['privacy:metadata:enrol_lti_users:userid'] = 'ID-ul utilizatorului';
$string['registration'] = 'Înregistrare instrument publicat';
$string['registrationurl'] = 'Adresa URL de înregistrare';
$string['registrationurl_help'] = 'Dacă este utilizată o adresă URL de înregistrare (numită și URL proxy), atunci instrumentul este configurat automat.';
$string['remotesystem'] = 'Sistem de la distanță';
$string['requirecompletion'] = 'Solicitați finalizarea cursului sau a activității înainte de sincronizarea notelor';
$string['returnurlnotset'] = 'Adresa URL de returnare nu a fost setată.';
$string['roleinstructor'] = 'Rolul formatorului';
$string['roleinstructor_help'] = 'Rolul atribuit în instrument profesorului la distanță.';
$string['rolelearner'] = 'Rol pentru cursant';
$string['rolelearner_help'] = 'Rolul atribuit în instrument studentului îndepărtat.';
$string['secret'] = 'Secret';
$string['secret_help'] = 'Un șir de caractere care este partajat cu sistemul la distanță (consumatorul LTI) pentru a oferi acces la instrument.';
$string['sharedexternaltools'] = 'Publicat ca instrumente LTI';
$string['successfulregistration'] = 'Înregistrare reușită';
$string['tasksyncgrades'] = 'Publicați sub formă de sincronizare a instrumentului LTI';
$string['tasksyncmembers'] = 'Publicați ca sincronizare a utilizatorilor instrumentului LTI';
$string['toolsprovided'] = 'Instrumente publicate';
$string['toolsprovided_help'] = 'Un instrument poate fi partajat cu un alt site oferind, fie detalii de lansare, fie o adresă URL de înregistrare.';
$string['tooltobeprovided'] = 'Instrumentul care urmează să fie publicat';
$string['toolurl'] = 'Adresa URL a instrumentului';
$string['userdefaultvalues'] = 'Valorile implicite ale utilizatorului';
