<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'enrol_guest', language 'ru', version '3.9'.
 *
 * @package     enrol_guest
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['allowguests'] = 'Курс доступен гостю';
$string['guest:config'] = 'Настраивать экземпляры способа записи на курс «Гостевой доступ»';
$string['guestaccess_withoutpassword'] = 'Гостевой доступ';
$string['guestaccess_withpassword'] = 'Для гостевого доступа требуется пароль';
$string['password'] = 'Пароль';
$string['password_help'] = 'Использование пароля позволяет разрешить гостевой доступ к курсу только тем, кто знает пароль. Гости должны будут вводить пароль каждый раз при входе в курс.';
$string['passwordinvalid'] = 'Неверный пароль, попробуйте еще раз';
$string['passwordinvalidhint'] = 'Введен неверный пароль, попробуйте еще раз<br />(Подсказка - он начинается с «{$a}»)';
$string['pluginname'] = 'Гостевой доступ';
$string['pluginname_desc'] = 'Гостевой доступ предоставляет только временный доступ к курсу, а не реальную запись пользователей на курс.';
$string['privacy:metadata'] = 'Плагин зачисления «Гостевой доступ» не хранит никаких персональных данных.';
$string['requirepassword'] = 'Требовать пароль для гостевого доступа';
$string['requirepassword_desc'] = 'Требовать пароль доступа в новые курсы и предотвратить снятие пароля в существующих курсах.';
$string['showhint'] = 'Показывать подсказку';
$string['showhint_desc'] = 'Показывать первую букву пароля гостевого доступа.';
$string['status'] = 'Разрешить гостевой доступ';
$string['status_desc'] = 'Разрешить временный гостевой доступ по умолчанию.';
$string['status_help'] = 'Этот параметр определяет, может ли пользователь иметь гостевой доступ к курсу, без обязательной записи на него.';
$string['usepasswordpolicy'] = 'Использовать политику паролей';
$string['usepasswordpolicy_desc'] = 'Использовать политику паролей для паролей гостевого доступа';
